import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
const db = new PrismaClient();

// OPT-IN ONLY: run with `npm run db:seed`. Never runs automatically on deploy.
// Creates ONE demo organisation clearly labelled "Demo data" with generic
// sample businesses — no real business claims.
async function main() {
  const passwordHash = await hash("demo1234", 10);
  const user = await db.user.upsert({
    where: { email: "demo@localrank.ai" },
    update: {},
    create: { name: "Demo Owner", email: "demo@localrank.ai", passwordHash },
  });
  const org = await db.organization.upsert({
    where: { slug: "demo-org" },
    update: {},
    create: { name: "Demo Agency (Demo data)", slug: "demo-org", plan: "PROFESSIONAL" },
  });
  await db.membership.upsert({
    where: { userId_organizationId: { userId: user.id, organizationId: org.id } },
    update: {},
    create: { userId: user.id, organizationId: org.id, role: "AGENCY_OWNER" },
  });
  await db.subscription.upsert({
    where: { id: "demo-sub" },
    update: {},
    create: { id: "demo-sub", organizationId: org.id, plan: "PROFESSIONAL", billingPeriod: "monthly", status: "TRIALING" },
  });
  const spa = await db.location.create({ data: { organizationId: org.id, name: "Sample Spa Islamabad (Demo)", category: "Spa", city: "Islamabad", description: "A relaxing spa in Islamabad offering massages, facials and wellness treatments.", address: "Sample Street, F-7 Markaz, Islamabad", phone: "0300 0000000", website: "https://example.com", hours: "11 AM – 12 AM", photoCount: 12, isDemo: true } });
  const salon = await db.location.create({ data: { organizationId: org.id, name: "Sample Salon Rawalpindi (Demo)", category: "Beauty Salon", city: "Rawalpindi", description: "A friendly salon in Rawalpindi for hair, makeup and skincare.", address: "Sample Road, Saddar, Rawalpindi", phone: "0300 0000001", website: "https://example.com", hours: "10 AM – 9 PM", photoCount: 8, isDemo: true } });
  for (const loc of [spa, salon]) {
    await db.review.createMany({ data: [
      { locationId: loc.id, authorName: "Ayesha K.", rating: 5, text: "Great service, very clean and professional staff.", sentiment: "POSITIVE" },
      { locationId: loc.id, authorName: "Bilal M.", rating: 4, text: "Good experience overall, friendly team.", sentiment: "POSITIVE" },
      { locationId: loc.id, authorName: "Sara T.", rating: 2, text: "Wait was too long and the booking was confusing.", sentiment: "NEGATIVE" },
    ]});
    await db.post.create({ data: { locationId: loc.id, type: "WHATS_NEW", title: "Now open for weekend bookings", body: "Book your weekend slot today — limited spaces available.", status: "PUBLISHED", publishedAt: new Date() } });
    await db.keyword.createMany({ data: [
      { organizationId: org.id, locationId: loc.id, term: `${loc.category.toLowerCase()} in ${loc.city}`, intent: "Transactional", groupName: "Core", service: loc.category, source: "rule-based" },
      { organizationId: org.id, locationId: loc.id, term: `best ${loc.category.toLowerCase()} near me`, intent: "Transactional", groupName: "Near me", service: loc.category, source: "rule-based" },
    ]});
  }
  console.log("Seed complete. Demo login: demo@localrank.ai / demo1234");
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => db.$disconnect());
