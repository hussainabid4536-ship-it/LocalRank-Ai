# LocalRank AI — Deploy Checklist

## What is built (in ~/workspace/localrank-ai-code/)
- Next.js 14 App Router + TypeScript + Tailwind, Prisma + PostgreSQL, NextAuth (credentials + Google), Stripe, OpenAI (optional), Recharts
- 16 modules: Auth/organisations, Dashboard, Locations, AI SEO Audit (13-check deterministic scorer), Content Studio, Reviews (6 tones, human-approval gate for 1–2★), Google Posts (composer + preview + scheduler), Keywords, Rank Tracker (3×3/5×5/7×7 heatmaps), Competitors, Analytics (charts + CSV), Automations (all 10 workflows, run-now + logs), Clients & Team (7 roles, permissions map), Billing (4 plans), Super Admin, Integrations
- API routes: locations, reviews (+ draft/approve), posts, audits, keywords, rank-scans, competitors, automations (+ run), billing webhook, auth
- Lib: db.ts, auth.ts, permissions.ts, audit-engine.ts, content-generator.ts, sentiment.ts, rank-provider.ts, google.ts
- Prisma schema: all 20 entities (User, Organization, Membership, Client, Location, GoogleConnection, Review, ReviewReply, Post, SeoAudit, SeoRecommendation, Keyword, RankScan, RankPoint, Competitor, Automation, AutomationLog, Subscription, Invoice, Notification, AuditLog)
- Seed script (opt-in `npm run db:seed`): one "Demo data" org, 2 sample locations (spa Islamabad, salon Rawalpindi), sample reviews/posts/keywords. Demo login demo@localrank.ai / demo1234 — change/delete before launch.
- Files: README.md, .env.example (no real values), vercel.json, package.json (dev/build/start/db:push/db:seed), .gitignore

## What is PENDING (not live until the user connects it)
- **Google OAuth / GBP sync** — needs a Google Cloud project, GBP API approval, GOOGLE_CLIENT_ID/SECRET. UI shows "Pending integration"; sync/publish throw clear errors. Never scraped.
- **Stripe payments** — needs STRIPE_* keys + webhook. Plan switching updates the local subscription record only until connected.
- **OpenAI** — needs OPENAI_API_KEY. Without it, rule-based generator is used and labelled as such.
- **Keyword provider** — volume/difficulty show "—" until KEYWORD_PROVIDER is set. Never estimated.
- **Rank provider** — real ranks only from a configured provider; demo scans only with DEMO_MODE=true, labelled demo.
- **Calls / clicks / directions** — show "Unavailable — connect Google" until GBP is connected.

## Exact Vercel steps (also in README.md)
1. Create free Postgres on Supabase or Neon; copy connection string.
2. Push this folder to a GitHub repo (or `npx vercel`).
3. Vercel → Add New Project → import repo (framework Next.js).
4. Set env vars from .env.example — minimum: DATABASE_URL, NEXTAUTH_URL (your Vercel domain), NEXTAUTH_SECRET (long random).
5. Deploy, then run `npx prisma db push` (creates tables).
6. Optional: `npm run db:seed` once for demo data, then delete/change the demo account.
7. Connect Google Cloud (GBP API), Stripe, OpenAI as needed — see README sections 7–9.
8. Pre-launch: DEMO_MODE=false, gate /admin by isSuperAdmin, set NEXTAUTH_URL to your custom domain if you add one.

## Build verification (2026-11-06, before delivery)
- Fixed 18 TypeScript errors found by `npx tsc --noEmit` (now 0 errors): missing `city` on
  `ProfileInput`, untyped callbacks in audits/posts/reviews/rank-scans routes, `z.enum([3,5,7])`
  changed to `z.union([z.literal(3), z.literal(5), z.literal(7)])`, `Role` now defined locally
  in `src/lib/permissions.ts` instead of importing it from `@prisma/client`, and the Analytics
  page now imports Recharts components statically instead of via `next/dynamic`.
- Fixed `next.config.mjs`, which contained TypeScript syntax in a `.mjs` file (build failed to
  load it); it is now plain JS.
- `npx next build` compiles successfully and passes type-checking. Its final "collecting page
  data" step could NOT run in this workspace because `prisma generate` needs to download the
  Prisma query engine from binaries.prisma.sh and that network call is blocked here. On Vercel
  this is not an issue: the build command is `prisma generate && next build` and Vercel has
  network access, so the client is generated first. If Vercel's build ever fails at that step,
  check the `prisma generate` log line first.
- Deliverable ZIP: `~/workspace/LocalRank-AI-Deployable-Code.zip` (104 KB, 107 files,
  excludes `node_modules/` and `.next/`).

## Known limitations in this build
- Clients page is a management surface over locations; a dedicated /api/clients CRUD endpoint is noted in-page and follows the same pattern as /api/locations (not yet wired).
- Admin page shows organisation-scoped counts and a capability checklist; full cross-org admin tables require the /api/admin endpoints (noted in-page) and an isSuperAdmin gate before public launch.
- The location form is add-only (edit by re-adding / via API); delete is via Prisma Studio or API.
- `npm run build` result: see the delivery report (build was run and fixed until passing in the workspace).
