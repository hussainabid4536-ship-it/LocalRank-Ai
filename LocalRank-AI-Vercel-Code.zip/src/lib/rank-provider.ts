// Rank provider module — replaceable integration layer.
// Real rank data ONLY comes from a configured provider. Without one, scans
// return an error, except in DEMO_MODE where a clearly-labelled demo scan
// may be generated. Demo ranks are never presented as real Google data.
export interface RankPointData { x: number; y: number; rank: number | null; }

export function providerConfigured(): boolean {
  return Boolean(process.env.RANK_PROVIDER && process.env.RANK_PROVIDER_API_KEY);
}
export function demoMode(): boolean {
  return process.env.DEMO_MODE === "true";
}

// Deterministic pseudo-random demo ranks (seeded by keyword+grid) so a demo
// scan is reproducible. Labelled demo only.
export function generateDemoGrid(keyword: string, gridSize: number): RankPointData[] {
  let seed = 0;
  for (const ch of keyword) seed = (seed * 31 + ch.charCodeAt(0)) % 100000;
  const pts: RankPointData[] = [];
  for (let y = 0; y < gridSize; y++) for (let x = 0; x < gridSize; x++) {
    seed = (seed * 1103515245 + 12345) % 2147483648;
    const rank = 1 + (seed % 20);
    pts.push({ x, y, rank });
  }
  return pts;
}

export function rankColor(rank: number | null): string {
  if (rank === null) return "#e2e8f0";
  if (rank <= 3) return "#16a34a";
  if (rank <= 10) return "#84cc16";
  if (rank <= 20) return "#f59e0b";
  return "#dc2626";
}
