// Rule-based content generator. Uses only the business details the user
// entered + their keywords + chosen tone. If OPENAI_API_KEY is set, the API
// route may call OpenAI instead; this generator is the graceful fallback and
// is never presented as a live AI call.
export type Tone = "Professional" | "Friendly" | "Short and direct" | "Appreciative" | "Apologetic" | "Service recovery";

export interface BusinessCtx { name: string; category: string; city?: string | null; services?: string[]; keywords?: string[]; }

const toneOpen: Record<Tone, string> = {
  Professional: "Welcome to",
  Friendly: "Looking for a friendly, reliable",
  "Short and direct": "",
  Appreciative: "Thank you for choosing",
  Apologetic: "We are sorry — and we want to make it right at",
  "Service recovery": "We hear you, and we are fixing this at",
};

export function generateDescription(b: BusinessCtx, tone: Tone = "Professional"): string {
  const kws = (b.keywords || []).slice(0, 3).join(", ");
  const svcs = (b.services || []).slice(0, 4).join(", ");
  const city = b.city ? ` in ${b.city}` : "";
  let text = `${toneOpen[tone]} ${b.name} — a trusted ${b.category.toLowerCase()}${city}.`;
  if (svcs) text += ` We offer ${svcs}.`;
  if (kws) text += ` Customers find us for ${kws}.`;
  text += ` Visit us today or call to book — we look forward to serving you.`;
  return text.slice(0, 750);
}

export function generateServiceDescription(b: BusinessCtx, service: string): string {
  return `${service} at ${b.name}${b.city ? `, ${b.city}` : ""} — professional, reliable and tailored to you. Book today and experience the difference.`;
}

export function generatePost(b: BusinessCtx, type: string, topic: string): { title: string; body: string } {
  const title = type === "OFFER" ? `Special offer at ${b.name}` : type === "EVENT" ? `${topic} — ${b.name}` : `${topic} at ${b.name}`;
  const body = `${b.name}${b.city ? ` in ${b.city}` : ""} — ${topic}. ${type === "OFFER" ? "Limited time only. Call or message us to claim it." : "Visit us today or book online."}`;
  return { title, body: body.slice(0, 1500) };
}

export function generateMeta(b: BusinessCtx, page: string): { title: string; description: string } {
  const kw = (b.keywords || [])[0] || b.category;
  return {
    title: `${page} | ${b.name} — ${kw}${b.city ? ` in ${b.city}` : ""}`.slice(0, 60),
    description: `${b.name} offers ${page.toLowerCase()}${b.city ? ` in ${b.city}` : ""}. ${kw}. Book today.`.slice(0, 160),
  };
}

export const CHAR_LIMITS = { description: 750, post: 1500, metaTitle: 60, metaDescription: 160, service: 300 };
