import { getServerSession } from "next-auth";
import { authOptions } from "./auth";
import { db } from "./db";
import { NextResponse } from "next/server";

export async function requireSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  const user = await db.user.findUnique({ where: { email: session.user.email }, include: { memberships: { include: { organization: true } } } });
  return user;
}

// Returns the user's first organisation (created on first login / register).
// All API queries must scope by this organisationId — multi-tenancy.
export async function requireOrg() {
  const user = await requireSession();
  if (!user) return null;
  const membership = user.memberships[0];
  if (!membership) return null;
  return { user, organization: membership.organization, role: membership.role };
}

export function unauthorized() {
  return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
}
export function forbidden(msg = "Forbidden") {
  return NextResponse.json({ error: msg }, { status: 403 });
}
export function paginate(searchParams: URLSearchParams) {
  const page = Math.max(1, Number(searchParams.get("page") || 1));
  const perPage = Math.min(50, Math.max(1, Number(searchParams.get("perPage") || 20)));
  return { page, perPage, skip: (page - 1) * perPage, take: perPage };
}
