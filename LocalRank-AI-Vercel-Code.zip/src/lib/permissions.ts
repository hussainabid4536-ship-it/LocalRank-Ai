// Role values mirror the Role enum in prisma/schema.prisma. Defined locally
// (not imported from @prisma/client) so this module type-checks even before
// `prisma generate` has run against the current schema.
export type Role = "SUPER_ADMIN" | "AGENCY_OWNER" | "AGENCY_MANAGER" | "SEO_SPECIALIST" | "REVIEW_MANAGER" | "BUSINESS_OWNER" | "BUSINESS_STAFF";

// Permission map: which roles may do what. Enforced server-side in API routes
// via requirePermission() and in the UI by hiding actions.
export const PERMISSIONS = {
  locations: { view: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","REVIEW_MANAGER","BUSINESS_OWNER","BUSINESS_STAFF"], manage: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","BUSINESS_OWNER"] },
  reviews: { view: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","REVIEW_MANAGER","BUSINESS_OWNER","BUSINESS_STAFF"], reply: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","REVIEW_MANAGER","BUSINESS_OWNER"], approve: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","BUSINESS_OWNER"] },
  posts: { view: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","REVIEW_MANAGER","BUSINESS_OWNER","BUSINESS_STAFF"], manage: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","BUSINESS_OWNER"] },
  reports: { view: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","BUSINESS_OWNER"], manage: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER"] },
  team: { view: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","BUSINESS_OWNER"], manage: ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER"] },
  billing: { view: ["SUPER_ADMIN","AGENCY_OWNER","BUSINESS_OWNER"], manage: ["SUPER_ADMIN","AGENCY_OWNER"] },
  admin: { view: ["SUPER_ADMIN"] },
} as const;

export type PermissionArea = keyof typeof PERMISSIONS;
export type PermissionAction = "view" | "manage" | "reply" | "approve";

export function canDo(role: Role | string | null | undefined, area: PermissionArea, action: string): boolean {
  if (!role) return false;
  if (role === "SUPER_ADMIN") return true;
  const list = (PERMISSIONS[area] as Record<string, readonly string[]>)[action];
  return list ? (list as readonly string[]).includes(role as string) : false;
}

export const ALL_ROLES: Role[] = ["SUPER_ADMIN","AGENCY_OWNER","AGENCY_MANAGER","SEO_SPECIALIST","REVIEW_MANAGER","BUSINESS_OWNER","BUSINESS_STAFF"];

export const PLAN_LIMITS: Record<string, { locations: number; label: string; monthlyUsd: number; yearlyUsd: number }> = {
  STARTER: { locations: 1, label: "Starter", monthlyUsd: 29, yearlyUsd: 290 },
  PROFESSIONAL: { locations: 5, label: "Professional", monthlyUsd: 79, yearlyUsd: 790 },
  AGENCY: { locations: 25, label: "Agency", monthlyUsd: 199, yearlyUsd: 1990 },
  ENTERPRISE: { locations: 9999, label: "Enterprise", monthlyUsd: 499, yearlyUsd: 4990 },
};
