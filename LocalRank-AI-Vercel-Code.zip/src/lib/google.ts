// Google Business Profile API client — integration layer only.
// No scraping, no Maps scraping, no fabricated GBP data.
// All live calls require GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET and an
// organisation GoogleConnection with a valid token. Until configured, every
// function throws a clear "pending integration" error that the UI surfaces.
export function googleConfigured(): boolean {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}
export function gbpApiEnabled(): boolean {
  return googleConfigured() && process.env.GBP_API_ENABLED === "true";
}
export function googleAuthUrl(redirectUri: string): string {
  if (!googleConfigured()) throw new Error("Google integration is pending: set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.");
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "https://www.googleapis.com/auth/business.manage https://www.googleapis.com/auth/plus.business.manage",
    access_type: "offline",
    prompt: "consent",
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}
// NOTE: token exchange / location import / post publish go here once the
// Google Cloud project is approved for the GBP API. Implement with the
// official googleapis client; never scrape Google Maps.
export async function syncLocations(): Promise<never> {
  throw new Error("Google Business Profile sync is pending integration — connect Google first (see Settings → Integrations).");
}
export async function publishPost(): Promise<never> {
  throw new Error("Google Posts publishing is pending integration — connect Google first.");
}
