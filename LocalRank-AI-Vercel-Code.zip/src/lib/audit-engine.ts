import { z } from "zod";

export interface AuditCheck { id: string; label: string; passed: boolean; points: number; max: number; detail: string; }
export interface AuditIssue { check: string; priority: "HIGH" | "MEDIUM" | "LOW"; detail: string; }
export interface AuditResult { score: number; checks: AuditCheck[]; issues: AuditIssue[]; recommendations: string[]; }

export interface ProfileInput {
  name: string; category?: string | null; description?: string | null;
  phone?: string | null; website?: string | null; hours?: string | null;
  photoCount?: number; services?: string[]; keywords?: string[];
  avgRating?: number; reviewCount?: number; recentReviews?: number;
  city?: string | null;
}

// Deterministic 0-100 scorer. No AI call, no invented data: every check is
// computed from stored profile fields only. Missing data fails its check.
export function runAudit(p: ProfileInput): AuditResult {
  const checks: AuditCheck[] = [];
  const add = (id: string, label: string, passed: boolean, points: number, max: number, detail: string) =>
    checks.push({ id, label, passed, points: passed ? points : 0, max, detail });
  add("name", "Business name present", !!p.name?.trim(), 8, 8, p.name ? `Name: ${p.name}` : "No business name stored.");
  add("category", "Primary category set", !!p.category && p.category !== "Local Business", 8, 8, p.category || "Default category only.");
  const descLen = (p.description || "").length;
  add("description", "Description 100–750 chars", descLen >= 100 && descLen <= 750, 10, 10, descLen === 0 ? "No description." : `${descLen} characters.`);
  add("services", "Services listed", (p.services?.length || 0) >= 3, 8, 8, `${p.services?.length || 0} services listed.`);
  add("contact", "Phone number present", !!p.phone, 8, 8, p.phone || "No phone number.");
  add("website", "Website URL present", !!p.website, 7, 7, p.website || "No website URL.");
  add("hours", "Opening hours set", !!p.hours, 7, 7, p.hours || "No opening hours.");
  add("photos", "At least 10 photos", (p.photoCount || 0) >= 10, 8, 8, `${p.photoCount || 0} photos.`);
  add("rating", "Average rating 4.0+", (p.avgRating || 0) >= 4, 8, 8, p.avgRating ? `${p.avgRating.toFixed(1)} average rating.` : "No rating data.");
  add("reviews", "Review activity (10+ reviews, recent)", (p.reviewCount || 0) >= 10 && (p.recentReviews || 0) > 0, 10, 10, `${p.reviewCount || 0} reviews, ${p.recentReviews || 0} in the last 30 days.`);
  const filled = [p.name, p.category, p.description, p.phone, p.website, p.hours].filter(Boolean).length;
  add("completeness", "Profile completeness", filled >= 6, 8, 8, `${filled}/6 core fields filled.`);
  add("keywords", "Local keywords in description", (p.keywords || []).some((k) => (p.description || "").toLowerCase().includes(k.toLowerCase())), 5, 5, (p.keywords || []).length ? "Checked against tracked keywords." : "No keywords tracked yet.");
  add("website-signals", "Website local signals", !!p.website && !!p.city, 5, 5, p.website ? "Website present; add city landing pages for full marks." : "No website to evaluate.");
  const score = checks.reduce((s, c) => s + c.points, 0);
  const issues: AuditIssue[] = checks.filter((c) => !c.passed).map((c) => ({
    check: c.label,
    priority: c.max >= 10 ? "HIGH" : c.max >= 8 ? "MEDIUM" : "LOW",
    detail: c.detail,
  }));
  const recommendations = issues.map((i) => `Fix: ${i.check} — ${i.detail}`);
  if (score >= 80) recommendations.push("Profile is strong — focus on fresh reviews and weekly Google Posts.");
  return { score, checks, issues, recommendations };
}

export const auditInputSchema = z.object({ locationId: z.string().min(1) });
