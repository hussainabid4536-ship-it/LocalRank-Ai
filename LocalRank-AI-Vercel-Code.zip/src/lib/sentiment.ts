// Rule-based sentiment: keyword lists only, no external API, no invented data.
export type Sentiment = "POSITIVE" | "NEUTRAL" | "NEGATIVE";
const POS = ["great", "excellent", "amazing", "love", "best", "wonderful", "friendly", "clean", "professional", "recommend", "perfect", "lovely", "fantastic"];
const NEG = ["bad", "terrible", "awful", "worst", "rude", "dirty", "slow", "disappoint", "poor", "never", "waste", "angry", "unhappy", "complaint"];

export function classifySentiment(text: string | null | undefined, rating: number): Sentiment {
  if (rating <= 2) return "NEGATIVE";
  if (rating >= 4) return "POSITIVE";
  const t = (text || "").toLowerCase();
  const neg = NEG.filter((w) => t.includes(w)).length;
  const pos = POS.filter((w) => t.includes(w)).length;
  if (neg > pos) return "NEGATIVE";
  if (pos > neg) return "POSITIVE";
  return "NEUTRAL";
}

export function draftReply(opts: { businessName: string; author: string; rating: number; text?: string | null; tone: string }): string {
  const { businessName, author, rating, tone } = opts;
  const first = author.split(" ")[0] || "there";
  if (rating <= 2) {
    if (tone === "Service recovery") return `Hi ${first}, thank you for telling us — we are sorry your visit did not meet expectations. Please message us directly so we can make this right. — Team ${businessName}`;
    if (tone === "Apologetic") return `Hi ${first}, we sincerely apologise for your experience at ${businessName}. Your feedback matters and we would love the chance to fix this.`;
    return `Hi ${first}, thank you for your honest feedback. We are sorry to hear this and would like to understand what happened — please reach out to us directly. — ${businessName}`;
  }
  if (tone === "Short and direct") return `Thanks ${first}! Glad you enjoyed ${businessName}. See you again soon.`;
  if (tone === "Appreciative") return `Thank you so much, ${first}! We really appreciate your kind words and your support for ${businessName}.`;
  if (tone === "Friendly") return `Hi ${first}! Thanks for the lovely review — it made our day. Hope to see you again soon at ${businessName}!`;
  return `Thank you, ${first}, for your review of ${businessName}. We are glad you had a great experience and look forward to welcoming you again.`;
}
