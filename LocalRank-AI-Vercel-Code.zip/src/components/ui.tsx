"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import { useState } from "react";

const NAV = [
  ["Dashboard", "/dashboard"], ["Locations", "/dashboard/locations"], ["AI SEO Audit", "/dashboard/audit"],
  ["Content Studio", "/dashboard/content"], ["Reviews", "/dashboard/reviews"], ["Google Posts", "/dashboard/posts"],
  ["Keywords", "/dashboard/keywords"], ["Rank Tracker", "/dashboard/rank-tracker"], ["Competitors", "/dashboard/competitors"],
  ["Analytics", "/dashboard/analytics"], ["Automations", "/dashboard/automations"], ["Clients", "/dashboard/clients"],
  ["Team", "/dashboard/team"], ["Billing", "/dashboard/billing"], ["Integrations", "/dashboard/settings/integrations"],
  ["Super Admin", "/admin"],
];
export function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (<div className="card"><p className="text-xs text-slate-500">{label}</p><p className="text-2xl font-bold text-navy mt-1">{value}</p>{sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}</div>);
}
export function PageHead({ title, sub, children }: { title: string; sub?: string; children?: React.ReactNode }) {
  return (<div className="flex flex-wrap items-start justify-between gap-3 mb-5"><div><h1 className="text-2xl font-bold text-navy">{title}</h1>{sub && <p className="text-sm text-slate-600 mt-1">{sub}</p>}</div><div className="flex gap-2">{children}</div></div>);
}
export function Empty({ title, body }: { title: string; body: string }) {
  return (<div className="card text-center py-10"><h3 className="font-semibold">{title}</h3><p className="text-sm text-slate-600 mt-1">{body}</p></div>);
}
export default function DashboardShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname(); const { data: session } = useSession(); const [open, setOpen] = useState(false);
  return (<div className="min-h-screen flex">
    <aside className={`${open ? "block" : "hidden"} md:block w-64 shrink-0 bg-navy text-white min-h-screen fixed md:static z-20`}>
      <div className="p-5 flex items-center gap-2"><span className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold">LR</span><span className="font-bold">LocalRank AI</span></div>
      <nav className="px-3 pb-6 space-y-1">{NAV.map(([label, href]) => (
        <Link key={href} href={href} onClick={() => setOpen(false)} className={`block px-3 py-2 rounded-lg text-sm ${pathname === href ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/10"}`}>{label}</Link>))}
      </nav>
    </aside>
    <div className="flex-1 min-w-0">
      <header className="bg-white border-b px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button className="md:hidden btn-secondary" onClick={() => setOpen(!open)}>Menu</button>
        <span className="font-semibold text-navy truncate">{NAV.find(([, h]) => pathname === h)?.[0] || "LocalRank AI"}</span>
        <span className="ml-auto text-sm text-slate-600 truncate">{session?.user?.email}</span>
        <button className="btn-secondary" onClick={() => signOut({ callbackUrl: "/login" })}>Sign out</button>
      </header>
      <main className="p-4 md:p-6 max-w-7xl mx-auto">{children}</main>
    </div>
  </div>);
}
