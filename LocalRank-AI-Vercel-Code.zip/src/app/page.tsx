import Link from "next/link";
export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <header className="border-b"><div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2"><span className="w-9 h-9 rounded-lg bg-navy text-white flex items-center justify-center font-bold">LR</span><span className="font-bold text-lg text-navy">LocalRank AI</span></div>
        <div className="flex gap-3"><Link href="/login" className="btn-secondary">Sign in</Link><Link href="/register" className="btn">Get started</Link></div>
      </div></header>
      <section className="max-w-6xl mx-auto px-6 py-20 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-navy">Rank higher on Google Maps.<br/>Win more local customers.</h1>
        <p className="mt-4 text-slate-600 max-w-2xl mx-auto">LocalRank AI manages your Google Business Profiles, audits local SEO, drafts review replies, schedules Google Posts and tracks map rankings — for agencies and local businesses.</p>
        <div className="mt-8 flex gap-3 justify-center"><Link href="/register" className="btn">Start free trial</Link><Link href="/login" className="btn-secondary">Sign in</Link></div>
        <div className="mt-12 grid md:grid-cols-4 gap-4 text-left">
          {[["AI SEO Audit","0–100 health score with a fix checklist."],["Review Management","AI reply drafts with human approval."],["Google Posts","Composer, preview and scheduler."],["Rank Tracker","3×3 / 5×5 / 7×7 map grid heatmaps."]].map(([t,d])=>(
            <div key={t} className="card"><h3 className="font-semibold">{t}</h3><p className="text-sm text-slate-600 mt-1">{d}</p></div>))}
        </div>
        <p className="mt-10 text-xs text-slate-500">Google Business Profile sync, keyword volumes, rank data and payments require connected accounts — see Settings → Integrations after signing up. No data is fabricated.</p>
      </section>
    </main>
  );
}
