"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Comp { id: string; name: string; rating?: number | null; reviewCount?: number | null; category?: string; completeness?: number | null; notes?: string }
export default function CompetitorsPage() {
  const [items, setItems] = useState<Comp[]>([]); const [form, setForm] = useState({ name: "", category: "", rating: "", reviewCount: "", completeness: "" });
  const [msg, setMsg] = useState("");
  async function load() { const r = await fetch("/api/competitors?perPage=50"); const d = await r.json(); setItems(d.items || []); }
  useEffect(() => { load(); }, []);
  async function submit(e: React.FormEvent) { e.preventDefault();
    const r = await fetch("/api/competitors", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: form.name, category: form.category || undefined, rating: form.rating ? Number(form.rating) : undefined, reviewCount: form.reviewCount ? Number(form.reviewCount) : undefined, completeness: form.completeness ? Number(form.completeness) : undefined }) });
    if (r.ok) { setMsg("Competitor added."); setForm({ name: "", category: "", rating: "", reviewCount: "", completeness: "" }); load(); }
  }
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });
  return (<div>
    <PageHead title="Competitor Analysis" sub="Track competitors you add. Ratings and counts are the values you enter — verified data only, no estimates." />
    {msg && <p className="text-sm text-green-700 bg-green-50 p-2 rounded mb-3">{msg}</p>}
    <div className="grid md:grid-cols-2 gap-4">
      <form onSubmit={submit} className="card space-y-3"><h2 className="font-semibold">Add competitor</h2>
        <div><label className="label">Business name *</label><input required value={form.name} onChange={set("name")} /></div>
        <div><label className="label">Category</label><input value={form.category} onChange={set("category")} /></div>
        <div className="grid grid-cols-3 gap-3">
          <div><label className="label">Rating</label><input type="number" step="0.1" min={0} max={5} value={form.rating} onChange={set("rating")} /></div>
          <div><label className="label">Reviews</label><input type="number" min={0} value={form.reviewCount} onChange={set("reviewCount")} /></div>
          <div><label className="label">Completeness %</label><input type="number" min={0} max={100} value={form.completeness} onChange={set("completeness")} /></div>
        </div>
        <button className="btn">Add competitor</button>
      </form>
      <div className="space-y-3">{items.length === 0 ? <Empty title="No competitors yet" body="Add the businesses you compete with on Google Maps." /> :
        items.map((c) => (<div key={c.id} className="card"><h3 className="font-semibold">{c.name}</h3><p className="text-sm text-slate-600">{c.category || "—"} • {c.rating ? `${c.rating}★` : "Rating unknown"} • {c.reviewCount ?? "—"} reviews • Profile {c.completeness ?? "—"}% complete</p>
        <p className="text-sm text-slate-600 mt-2">Gap insight: {(c.completeness ?? 0) < 80 ? "Their profile looks incomplete — a complete profile with fresh photos and posts is your opening." : "Their profile is fairly complete — compete on review volume and fresh posts."}</p></div>))}
      </div>
    </div>
  </div>);
}
