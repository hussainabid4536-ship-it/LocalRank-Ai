"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Loc { id: string; name: string }
interface Audit { id: string; score: number; createdAt: string; location?: { name: string }; checks?: { label: string; passed: boolean; detail: string }[]; issues?: { check: string; priority: string; detail: string }[]; recommendations?: string[] }
export default function AuditPage() {
  const [locs, setLocs] = useState<Loc[]>([]); const [locId, setLocId] = useState("");
  const [audit, setAudit] = useState<Audit | null>(null); const [history, setHistory] = useState<Audit[]>([]);
  const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  useEffect(() => { fetch("/api/locations?perPage=50").then((r) => r.json()).then((d) => { setLocs(d.items || []); if (d.items?.[0]) setLocId(d.items[0].id); }); fetch("/api/audits").then((r) => r.json()).then((d) => setHistory(d.items || [])); }, []);
  async function run() { if (!locId) return; setLoading(true); setError("");
    const r = await fetch("/api/audits", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ locationId: locId }) });
    const d = await r.json(); setLoading(false);
    if (!r.ok) { setError(d.error || "Audit failed."); return; }
    setAudit(d); setHistory((h) => [d, ...h]);
  }
  const prev = history.filter((h) => audit && h.id !== audit.id)[0];
  return (<div>
    <PageHead title="AI SEO Audit" sub="Deterministic 0–100 score from your stored profile — missing data is marked, never invented.">
      <select value={locId} onChange={(e) => setLocId(e.target.value)} className="!w-auto">{locs.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
      <button className="btn" onClick={run} disabled={loading || !locId}>{loading ? "Running…" : "Run audit"}</button>
      {audit && <button className="btn-secondary" onClick={() => window.print()}>Print / save PDF</button>}
    </PageHead>
    {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded mb-3">{error}</p>}
    {locs.length === 0 && <Empty title="No locations yet" body="Add a location first, then run an audit on it." />}
    {audit && (<div className="space-y-4">
      <div className="card flex items-center gap-6"><div><p className="text-xs text-slate-500">SEO health score</p><p className="text-4xl font-bold text-navy">{audit.score}<span className="text-lg text-slate-400">/100</span></p></div>
      {prev && <p className="text-sm text-slate-600">Previous audit: {prev.score}/100 ({audit.score - prev.score >= 0 ? "+" : ""}{audit.score - prev.score} since then)</p>}</div>
      <div className="card"><h2 className="font-semibold mb-3">Checks (13)</h2><ul className="space-y-2">{(audit.checks || []).map((c) => (<li key={c.label} className="text-sm flex gap-2"><span>{c.passed ? "✅" : "❌"}</span><span><b>{c.label}</b> — {c.detail}</span></li>))}</ul></div>
      <div className="card"><h2 className="font-semibold mb-3">Issues & recommendations</h2><ul className="space-y-2">{(audit.recommendations || []).map((r, i) => (<li key={i} className="text-sm">• {r}</li>))}</ul></div>
    </div>)}
    <div className="card mt-4"><h2 className="font-semibold mb-3">Audit history</h2>
      {history.length === 0 ? <p className="text-sm text-slate-500">No audits yet.</p> : <ul className="text-sm space-y-1">{history.map((h) => (<li key={h.id}>{h.location?.name} — <b>{h.score}/100</b> — {new Date(h.createdAt).toLocaleString()}</li>))}</ul>}
    </div>
  </div>);
}
