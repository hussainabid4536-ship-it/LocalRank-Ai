"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { PageHead, Stat, Empty } from "@/components/ui";

export default function DashboardPage() {
  const [days, setDays] = useState(30);
  const [data, setData] = useState<{ locations: unknown[]; reviews: unknown[]; posts: unknown[]; audits: unknown[] } | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      setLoading(true);
      const [loc, rev, posts, audits] = await Promise.all([
        fetch("/api/locations?perPage=50").then((r) => r.json()),
        fetch("/api/reviews?perPage=50").then((r) => r.json()),
        fetch("/api/posts?perPage=50").then((r) => r.json()),
        fetch("/api/audits").then((r) => r.json()),
      ]);
      setData({ locations: loc.items || [], reviews: rev.items || [], posts: posts.items || [], audits: audits.items || [] });
      setLoading(false);
    })();
  }, []);
  if (loading) return <p className="text-slate-500">Loading dashboard…</p>;
  const reviews = (data?.reviews || []) as { rating: number; reviewedAt: string; replies?: { status: string }[] }[];
  const cutoff = new Date(Date.now() - days * 864e5);
  const recent = reviews.filter((r) => new Date(r.reviewedAt) >= cutoff);
  const avg = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : "—";
  const pending = reviews.filter((r) => (r.replies || []).some((x) => x.status === "PENDING_APPROVAL")).length;
  const published = ((data?.posts || []) as { status: string }[]).filter((p) => p.status === "PUBLISHED").length;
  const audits = (data?.audits || []) as { score: number }[];
  const health = audits.length ? Math.round(audits.reduce((s, a) => s + a.score, 0) / audits.length) : null;
  return (<div>
    <PageHead title="Dashboard" sub="Your local SEO performance at a glance.">
      <select value={days} onChange={(e) => setDays(Number(e.target.value))} className="!w-auto">
        <option value={7}>Last 7 days</option><option value={30}>Last 30 days</option><option value={90}>Last 90 days</option>
      </select>
      <Link href="/dashboard/locations" className="btn">Add location</Link>
    </PageHead>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <Stat label="Locations" value={String((data?.locations || []).length)} />
      <Stat label="Avg rating" value={avg} sub={`${reviews.length} reviews total`} />
      <Stat label={`New reviews (${days}d)`} value={String(recent.length)} />
      <Stat label="Pending approvals" value={String(pending)} sub="Negative replies need you" />
      <Stat label="Published posts" value={String(published)} />
      <Stat label="SEO health" value={health === null ? "—" : `${health}/100`} sub={health === null ? "Run an audit" : "Latest audit average"} />
      <Stat label="Calls / clicks / directions" value="Unavailable" sub="Connect Google to see real data" />
      <Stat label="AI recommendations" value={health !== null && health < 70 ? "Fix profile gaps" : "Keep posting weekly"} />
    </div>
    <div className="grid md:grid-cols-2 gap-4 mt-4">
      <div className="card"><h2 className="font-semibold mb-3">Recent reviews</h2>
        {reviews.length === 0 ? <Empty title="No reviews yet" body="Add a location, then add reviews (or connect Google to import them)." /> :
        <ul className="space-y-2">{reviews.slice(0, 5).map((r, i) => (<li key={i} className="text-sm border-b pb-2">{"★".repeat(r.rating)} — {new Date(r.reviewedAt).toLocaleDateString()}</li>))}</ul>}
      </div>
      <div className="card"><h2 className="font-semibold mb-3">Next steps</h2>
        <ul className="text-sm space-y-2 list-disc pl-5 text-slate-700">
          <li>Add your first location (or connect Google in Integrations).</li>
          <li>Run an AI SEO Audit and work through the checklist.</li>
          <li>Reply to pending reviews — negative ones need your approval.</li>
          <li>Schedule this week&apos;s Google Posts.</li>
        </ul>
      </div>
    </div>
  </div>);
}
