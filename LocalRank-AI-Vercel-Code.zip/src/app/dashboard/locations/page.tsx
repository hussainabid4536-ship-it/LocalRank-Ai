"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Loc { id: string; name: string; category: string; city?: string; phone?: string; website?: string; _count?: { reviews: number; posts: number } }
export default function LocationsPage() {
  const [items, setItems] = useState<Loc[]>([]); const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: "", category: "Spa", city: "Islamabad", phone: "", website: "", description: "", address: "", hours: "", photoCount: 0 });
  const [msg, setMsg] = useState(""); const [error, setError] = useState("");
  async function load() { setLoading(true); const r = await fetch("/api/locations?perPage=50"); const d = await r.json(); setItems(d.items || []); setLoading(false); }
  useEffect(() => { load(); }, []);
  async function submit(e: React.FormEvent) { e.preventDefault(); setMsg(""); setError("");
    const r = await fetch("/api/locations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { setError(d.error || "Could not save location."); return; }
    setMsg("Location saved."); setForm({ name: "", category: "Spa", city: "Islamabad", phone: "", website: "", description: "", address: "", hours: "", photoCount: 0 }); load();
  }
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm({ ...form, [k]: k === "photoCount" ? Number(e.target.value) : e.target.value });
  return (<div>
    <PageHead title="Locations" sub="Business locations in your organisation. Plan limits are enforced on save." />
    {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded mb-3">{error}</p>}
    {msg && <p className="text-sm text-green-700 bg-green-50 p-2 rounded mb-3">{msg}</p>}
    <div className="grid md:grid-cols-2 gap-4">
      <form onSubmit={submit} className="card space-y-3">
        <h2 className="font-semibold">Add / edit location</h2>
        <div><label className="label">Business name *</label><input required value={form.name} onChange={set("name")} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Category</label><input value={form.category} onChange={set("category")} /></div>
          <div><label className="label">City</label><input value={form.city} onChange={set("city")} /></div>
        </div>
        <div><label className="label">Description (max 750 chars)</label><textarea maxLength={750} value={form.description} onChange={set("description")} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Phone</label><input value={form.phone} onChange={set("phone")} /></div>
          <div><label className="label">Website</label><input value={form.website} onChange={set("website")} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Address</label><input value={form.address} onChange={set("address")} /></div>
          <div><label className="label">Hours</label><input value={form.hours} onChange={set("hours")} placeholder="11 AM – 12 AM" /></div>
        </div>
        <div><label className="label">Photo count</label><input type="number" min={0} value={form.photoCount} onChange={set("photoCount")} /></div>
        <button className="btn">Save location</button>
      </form>
      <div className="space-y-3">
        {loading ? <p className="text-slate-500">Loading…</p> : items.length === 0 ? <Empty title="No locations yet" body="Add your first location with the form, or connect Google in Integrations to import authorised locations." /> :
        items.map((l) => (<div key={l.id} className="card"><div className="flex justify-between"><div><h3 className="font-semibold">{l.name}</h3><p className="text-sm text-slate-600">{l.category} • {l.city || "—"}</p><p className="text-sm text-slate-600">{l.phone || "No phone"} • {l.website || "No website"}</p></div><span className="badge bg-slate-100">{l._count?.reviews || 0} reviews</span></div></div>))}
      </div>
    </div>
  </div>);
}
