"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";
import { rankColor } from "@/lib/rank-provider";

interface Loc { id: string; name: string }
interface Scan { id: string; keyword: string; gridSize: number; isDemo: boolean; createdAt: string; location?: { name: string }; points: { gridX: number; gridY: number; rank: number | null }[] }
export default function RankPage() {
  const [locs, setLocs] = useState<Loc[]>([]); const [scans, setScans] = useState<Scan[]>([]);
  const [form, setForm] = useState({ locationId: "", keyword: "spa in islamabad", gridSize: 3 });
  const [msg, setMsg] = useState(""); const [error, setError] = useState("");
  async function load() { const r = await fetch("/api/rank-scans"); const d = await r.json(); setScans(d.items || []); }
  useEffect(() => { fetch("/api/locations?perPage=50").then((r) => r.json()).then((d) => { setLocs(d.items || []); if (d.items?.[0]) setForm((f) => ({ ...f, locationId: d.items[0].id })); }); load(); }, []);
  async function run() { setMsg(""); setError("");
    const r = await fetch("/api/rank-scans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { setError(d.error || "Scan failed."); return; }
    setMsg(d.note || "Scan complete."); load();
  }
  const latest = scans[0];
  return (<div>
    <PageHead title="Maps Grid Rank Tracker" sub="Heatmap by grid point. Real ranks come only from a configured rank provider.">
      <select value={form.locationId} onChange={(e) => setForm({ ...form, locationId: e.target.value })} className="!w-auto">{locs.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
      <input value={form.keyword} onChange={(e) => setForm({ ...form, keyword: e.target.value })} className="!w-48" placeholder="Keyword" />
      <select value={form.gridSize} onChange={(e) => setForm({ ...form, gridSize: Number(e.target.value) })} className="!w-auto"><option value={3}>3×3</option><option value={5}>5×5</option><option value={7}>7×7</option></select>
      <button className="btn" onClick={run}>Run scan</button>
    </PageHead>
    {msg && <p className="text-sm text-green-700 bg-green-50 p-2 rounded mb-3">{msg}</p>}
    {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded mb-3">{error}</p>}
    {locs.length === 0 ? <Empty title="No locations yet" body="Add a location first." /> : latest ? (<div className="space-y-4">
      <div className="card"><h2 className="font-semibold">{latest.keyword} — {latest.location?.name} {latest.isDemo && <span className="badge bg-amber-100 text-amber-800 ml-2">DEMO — not real Google data</span>}</h2>
        <p className="text-xs text-slate-500 mt-1">{new Date(latest.createdAt).toLocaleString()} • {latest.gridSize}×{latest.gridSize} grid • Green = top 3, red = 20+</p>
        <div className="mt-4 inline-grid gap-1" style={{ gridTemplateColumns: `repeat(${latest.gridSize}, minmax(0,1fr))` }}>
          {latest.points.sort((a, b) => a.gridY - b.gridY || a.gridX - b.gridX).map((p, i) => (
            <div key={i} className="w-12 h-12 rounded flex items-center justify-center text-white text-sm font-bold" style={{ background: rankColor(p.rank) }}>{p.rank ?? "—"}</div>))}
        </div>
      </div>
      <div className="card"><h2 className="font-semibold mb-2">Scan history</h2><ul className="text-sm space-y-1">{scans.map((s) => (<li key={s.id}>{s.keyword} — {s.location?.name} — {s.gridSize}×{s.gridSize} {s.isDemo ? "(demo)" : ""} — {new Date(s.createdAt).toLocaleString()}</li>))}</ul></div>
    </div>) : <Empty title="No scans yet" body="Run your first scan above. Without a rank provider, only clearly-labelled demo scans are available (enable DEMO_MODE=true)." />}
  </div>);
}
