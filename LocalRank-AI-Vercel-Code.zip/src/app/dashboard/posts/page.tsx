"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Loc { id: string; name: string }
interface Post { id: string; title: string; body: string; type: string; status: string; ctaText?: string; scheduledAt?: string; location?: { name: string } }
export default function PostsPage() {
  const [locs, setLocs] = useState<Loc[]>([]); const [posts, setPosts] = useState<Post[]>([]);
  const [form, setForm] = useState({ locationId: "", type: "WHATS_NEW", title: "", body: "", ctaText: "Call now", scheduledAt: "" });
  const [msg, setMsg] = useState(""); const [error, setError] = useState("");
  async function load() { const r = await fetch("/api/posts?perPage=50"); const d = await r.json(); setPosts(d.items || []); }
  useEffect(() => { fetch("/api/locations?perPage=50").then((r) => r.json()).then((d) => { setLocs(d.items || []); if (d.items?.[0]) setForm((f) => ({ ...f, locationId: d.items[0].id })); }); load(); }, []);
  async function submit(e: React.FormEvent) { e.preventDefault(); setMsg(""); setError("");
    const r = await fetch("/api/posts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, status: form.scheduledAt ? "SCHEDULED" : "DRAFT" }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { setError(d.error || "Could not save post."); return; }
    setMsg(d.note || "Post saved."); load();
  }
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm({ ...form, [k]: e.target.value });
  return (<div>
    <PageHead title="Google Posts" sub="Composer with live preview. Publishing to Google requires the GBP integration." />
    {msg && <p className="text-sm text-green-700 bg-green-50 p-2 rounded mb-3">{msg}</p>}
    {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded mb-3">{error}</p>}
    {locs.length === 0 ? <Empty title="No locations yet" body="Add a location first." /> : (<div className="grid md:grid-cols-2 gap-4">
      <form onSubmit={submit} className="card space-y-3">
        <div><label className="label">Location</label><select value={form.locationId} onChange={set("locationId")}>{locs.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
        <div><label className="label">Type</label><select value={form.type} onChange={set("type")}><option value="WHATS_NEW">What&apos;s New</option><option value="OFFER">Offer</option><option value="EVENT">Event</option></select></div>
        <div><label className="label">Title</label><input required value={form.title} onChange={set("title")} /></div>
        <div><label className="label">Body (max 1500 chars)</label><textarea required maxLength={1500} value={form.body} onChange={set("body")} /></div>
        <div><label className="label">CTA text</label><input value={form.ctaText} onChange={set("ctaText")} /></div>
        <div><label className="label">Schedule (optional)</label><input type="datetime-local" value={form.scheduledAt} onChange={set("scheduledAt")} /></div>
        <button className="btn">Save post</button>
      </form>
      <div className="space-y-3">
        <div className="card"><h2 className="font-semibold mb-2">Live preview (Google-style)</h2>
          <div className="border rounded-lg p-4"><p className="font-semibold">{form.title || "Post title"}</p><p className="text-sm text-slate-600 mt-1">{form.body || "Post body…"}</p>{form.ctaText && <span className="btn mt-3">{form.ctaText}</span>}</div>
        </div>
        {posts.map((p) => (<div key={p.id} className="card"><div className="flex justify-between"><div><b>{p.title}</b><p className="text-sm text-slate-600">{p.location?.name} • {p.type}</p></div><span className="badge bg-slate-100">{p.status}</span></div><p className="text-sm mt-2">{p.body}</p>{p.scheduledAt && <p className="text-xs text-slate-500 mt-1">Scheduled: {new Date(p.scheduledAt).toLocaleString()}</p>}</div>))}
      </div>
    </div>)}
  </div>);
}
