"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Auto { id: string; name: string; workflow: string; status: string; schedule: string; lastRunAt?: string; logs: { id: string; message: string; success: boolean; createdAt: string }[] }
export default function AutomationsPage() {
  const [items, setItems] = useState<Auto[]>([]); const [msg, setMsg] = useState("");
  async function load() { const r = await fetch("/api/automations"); const d = await r.json(); setItems(d.items || []); }
  useEffect(() => { load(); }, []);
  async function toggle(a: Auto) { await fetch("/api/automations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: a.id, status: a.status === "ENABLED" ? "DISABLED" : "ENABLED" }) }); load(); }
  async function run(a: Auto) { const r = await fetch(`/api/automations/${a.id}/run`, { method: "POST" }); const d = await r.json(); setMsg(d.log?.message || d.error || "Ran."); load(); }
  return (<div>
    <PageHead title="Automation Center" sub="Semi-automated workflows. Publishing actions always default to AI draft + human approval." />
    {msg && <p className="text-sm bg-blue-50 text-blue-800 p-2 rounded mb-3">{msg}</p>}
    {items.length === 0 ? <Empty title="No automations yet" body="Automations are created automatically when your workspace is created. If this list is empty, re-register a workspace." /> :
    <div className="space-y-3">{items.map((a) => (<div key={a.id} className="card">
      <div className="flex flex-wrap justify-between gap-2 items-center"><div><h3 className="font-semibold">{a.name}</h3><p className="text-xs text-slate-500">Schedule: {a.schedule} • Last run: {a.lastRunAt ? new Date(a.lastRunAt).toLocaleString() : "Never"}</p></div>
      <div className="flex gap-2"><button className="btn-secondary" onClick={() => run(a)}>Run now</button><button className="btn" onClick={() => toggle(a)}>{a.status === "ENABLED" ? "Disable" : "Enable"}</button></div></div>
      <p className="text-xs mt-2"><span className={`badge ${a.status === "ENABLED" ? "bg-green-100 text-green-800" : "bg-slate-100"}`}>{a.status}</span></p>
      {(a.logs || []).length > 0 && <ul className="text-xs text-slate-600 mt-2 space-y-1">{a.logs.map((l) => (<li key={l.id}>{new Date(l.createdAt).toLocaleString()} — {l.message}</li>))}</ul>}
    </div>))}</div>}
  </div>);
}
