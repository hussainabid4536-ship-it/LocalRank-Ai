"use client";
import { useState } from "react";
import { PageHead } from "@/components/ui";

// Clients & workspaces are stored via Locations (clientId) in this build;
// this page is the management surface. Full client CRUD API can be added
// under /api/clients following the same pattern as /api/locations.
export default function ClientsPage() {
  const [msg, setMsg] = useState("");
  return (<div>
    <PageHead title="Clients & Workspaces" sub="Agency workspaces — assign locations to a client when you create them." />
    <div className="card max-w-xl">
      <p className="text-sm text-slate-700">Client records live on locations: when you add a location, pick the client it belongs to. Team members switch workspaces from the Team page.</p>
      <p className="text-sm text-slate-500 mt-3">A dedicated /api/clients CRUD endpoint follows the same multi-tenant pattern as /api/locations (organisationId-scoped, role-checked). Add it when you onboard your first agency clients.</p>
      <button className="btn mt-4" onClick={() => setMsg("Use the Locations page to add a client location — client workspaces are created per organisation on sign-up.")}>How clients work</button>
      {msg && <p className="text-sm bg-blue-50 p-2 rounded mt-3">{msg}</p>}
    </div>
  </div>);
}
