"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Reply { id: string; body: string; tone: string; status: string }
interface Review { id: string; authorName: string; rating: number; text?: string; sentiment: string; reviewedAt: string; location?: { name: string }; replies?: Reply[] }
const TONES = ["Professional","Friendly","Short and direct","Appreciative","Apologetic","Service recovery"];
export default function ReviewsPage() {
  const [items, setItems] = useState<Review[]>([]); const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(""); const [tone, setTone] = useState("Professional");
  const [msg, setMsg] = useState("");
  async function load() { setLoading(true); const r = await fetch(`/api/reviews?perPage=50${rating ? `&rating=${rating}` : ""}`); const d = await r.json(); setItems(d.items || []); setLoading(false); }
  useEffect(() => { load(); }, [rating]);
  async function draft(id: string) { const r = await fetch(`/api/reviews/${id}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tone }) }); const d = await r.json(); setMsg(d.note || "Draft created."); load(); }
  async function approve(replyId: string) {
    const res = await fetch(`/api/reviews/${replyId}/approve`, { method: "POST" }); const d = await res.json().catch(() => ({}));
    if (!res.ok) setMsg(d.error || "Approval failed."); else setMsg("Reply approved and marked published (GBP publish needs Google connected).");
    load();
  }
  const pending = items.filter((r) => (r.replies || []).some((x) => x.status === "PENDING_APPROVAL"));
  return (<div>
    <PageHead title="Review Management" sub="Negative reviews (1–2★) always require human approval before a reply is published.">
      <select value={rating} onChange={(e) => setRating(e.target.value)} className="!w-auto"><option value="">All ratings</option>{[5,4,3,2,1].map((n) => <option key={n} value={n}>{n}★</option>)}</select>
      <select value={tone} onChange={(e) => setTone(e.target.value)} className="!w-auto">{TONES.map((t) => <option key={t}>{t}</option>)}</select>
    </PageHead>
    {msg && <p className="text-sm bg-blue-50 text-blue-800 p-2 rounded mb-3">{msg}</p>}
    <p className="text-sm text-slate-600 mb-3">{pending.length} review(s) in the approval queue.</p>
    {loading ? <p className="text-slate-500">Loading…</p> : items.length === 0 ? <Empty title="No reviews yet" body="Add reviews from the API or connect Google to import them. Seed data includes sample reviews." /> :
    <div className="space-y-3">{items.map((r) => (<div key={r.id} className="card">
      <div className="flex justify-between flex-wrap gap-2"><div><b>{r.authorName}</b> — {"★".repeat(r.rating)} <span className="badge bg-slate-100 ml-2">{r.sentiment}</span> <span className="text-xs text-slate-500">{r.location?.name} • {new Date(r.reviewedAt).toLocaleDateString()}</span></div>
      <button className="btn-secondary" onClick={() => draft(r.id)}>Draft reply ({tone})</button></div>
      <p className="text-sm text-slate-700 mt-2">{r.text || "No text."}</p>
      {(r.replies || []).map((rep) => (<div key={rep.id} className="mt-3 bg-slate-50 border rounded-lg p-3">
        <p className="text-xs text-slate-500">{rep.tone} • {rep.status}</p><p className="text-sm mt-1">{rep.body}</p>
        {rep.status === "PENDING_APPROVAL" && <button className="btn mt-2" onClick={() => approve(rep.id)}>Approve & publish</button>}
        {rep.status === "DRAFT" && <p className="text-xs text-slate-500 mt-2">Draft only — edit in your reply workflow, then approve.</p>}
      </div>))}
    </div>))}</div>}
  </div>);
}
