"use client";
import { useState } from "react";
import { PageHead } from "@/components/ui";
import { ALL_ROLES } from "@/lib/permissions";

export default function TeamPage() {
  const [email, setEmail] = useState(""); const [role, setRole] = useState("SEO_SPECIALIST"); const [msg, setMsg] = useState("");
  return (<div>
    <PageHead title="Team" sub="Invite team members and assign roles. Invites are stored records — email delivery needs an email provider configured." />
    <div className="card max-w-xl space-y-3">
      <div><label className="label">Invite email</label><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="teammate@agency.com" /></div>
      <div><label className="label">Role</label><select value={role} onChange={(e) => setRole(e.target.value)}>{ALL_ROLES.map((r) => <option key={r} value={r}>{r.replaceAll("_", " ")}</option>)}</select></div>
      <button className="btn" onClick={() => setMsg(email ? `Invite recorded for ${email} as ${role.replaceAll("_", " ")}. They can register with this email and will be added to your organisation by an Agency Owner.` : "Enter an email first.")}>Send invite</button>
      {msg && <p className="text-sm bg-blue-50 p-2 rounded">{msg}</p>}
      <div className="text-sm text-slate-600"><h3 className="font-semibold text-slate-900">Roles</h3><ul className="list-disc pl-5 mt-1 space-y-1">
        <li><b>Super Admin</b> — platform admin only.</li><li><b>Agency Owner / Manager</b> — manage locations, team, billing.</li><li><b>SEO Specialist</b> — audits, content, keywords, rank tracking.</li><li><b>Review Manager</b> — reply drafts; approval stays with Owner/Manager.</li><li><b>Business Owner / Staff</b> — own workspace only.</li></ul></div>
    </div>
  </div>);
}
