"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";
import { generateDescription, generateServiceDescription, generatePost, generateMeta, CHAR_LIMITS } from "@/lib/content-generator";

interface Loc { id: string; name: string; category: string; city?: string }
export default function ContentPage() {
  const [locs, setLocs] = useState<Loc[]>([]); const [locId, setLocId] = useState("");
  const [kind, setKind] = useState<"description" | "service" | "post" | "meta">("description");
  const [tone, setTone] = useState("Professional"); const [topic, setTopic] = useState("Weekend bookings now open");
  const [keywords, setKeywords] = useState("spa in islamabad, best spa");
  const [output, setOutput] = useState("");
  useEffect(() => { fetch("/api/locations?perPage=50").then((r) => r.json()).then((d) => { setLocs(d.items || []); if (d.items?.[0]) setLocId(d.items[0].id); }); }, []);
  function gen() {
    const loc = locs.find((l) => l.id === locId); if (!loc) return;
    const ctx = { name: loc.name, category: loc.category, city: loc.city, keywords: keywords.split(",").map((s) => s.trim()).filter(Boolean), services: ["Massage", "Facial", "Hair care"] };
    if (kind === "description") setOutput(generateDescription(ctx, tone as never));
    else if (kind === "service") setOutput(generateServiceDescription(ctx, topic));
    else if (kind === "post") { const p = generatePost(ctx, "WHATS_NEW", topic); setOutput(`${p.title}\n\n${p.body}`); }
    else { const m = generateMeta(ctx, topic); setOutput(`Title (${m.title.length}/${CHAR_LIMITS.metaTitle}): ${m.title}\n\nDescription (${m.description.length}/${CHAR_LIMITS.metaDescription}): ${m.description}`); }
  }
  const limit = kind === "description" ? CHAR_LIMITS.description : kind === "post" ? CHAR_LIMITS.post : 1500;
  return (<div>
    <PageHead title="AI Content Studio" sub="Rule-based generator from your business details — edit everything before use. OpenAI is used only when OPENAI_API_KEY is set." />
    {locs.length === 0 ? <Empty title="No locations yet" body="Add a location first." /> : (<div className="grid md:grid-cols-2 gap-4">
      <div className="card space-y-3">
        <div><label className="label">Location</label><select value={locId} onChange={(e) => setLocId(e.target.value)}>{locs.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></div>
        <div><label className="label">Type</label><select value={kind} onChange={(e) => setKind(e.target.value as never)}>
          <option value="description">Business description</option><option value="service">Service description</option><option value="post">Google Post</option><option value="meta">Meta title & description</option></select></div>
        <div><label className="label">Tone</label><select value={tone} onChange={(e) => setTone(e.target.value)}>{["Professional","Friendly","Short and direct","Appreciative","Apologetic","Service recovery"].map((t) => <option key={t}>{t}</option>)}</select></div>
        <div><label className="label">Topic / service</label><input value={topic} onChange={(e) => setTopic(e.target.value)} /></div>
        <div><label className="label">Keywords (comma separated)</label><input value={keywords} onChange={(e) => setKeywords(e.target.value)} /></div>
        <button className="btn" onClick={gen}>Generate</button>
      </div>
      <div className="card"><h2 className="font-semibold mb-2">Output — editable</h2>
        <textarea rows={12} value={output} onChange={(e) => setOutput(e.target.value)} placeholder="Generated content will appear here…" />
        <p className="text-xs text-slate-500 mt-2">{output.length} / {limit} characters {output.length > limit ? "— over the Google limit, please shorten." : "— within limit."}</p>
        <button className="btn-secondary mt-2" onClick={() => navigator.clipboard?.writeText(output)}>Copy</button>
      </div>
    </div>)}
  </div>);
}
