"use client";
import { useState } from "react";
import { PageHead } from "@/components/ui";

export default function IntegrationsPage() {
  const [msg, setMsg] = useState("");
  const items = [
    { name: "Google Business Profile", status: "Pending integration", detail: "Set GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET and enable the GBP API in Google Cloud Console. OAuth connect, location import and post publishing are built behind this switch — never simulated." },
    { name: "OpenAI", status: "Optional", detail: "Set OPENAI_API_KEY to use live AI generation. Without it, Content Studio and reply drafts use the built-in deterministic generator (clearly labelled)." },
    { name: "Stripe", status: "Pending integration", detail: "Set STRIPE_SECRET_KEY, STRIPE_PUBLISHABLE_KEY and STRIPE_WEBHOOK_SECRET. Checkout and webhooks are stubbed until then." },
    { name: "Keyword provider", status: "Pending integration", detail: "Set KEYWORD_PROVIDER + KEYWORD_PROVIDER_API_KEY. Volume and difficulty stay blank (—) until then — never estimated." },
    { name: "Rank provider", status: "Pending integration", detail: "Set RANK_PROVIDER + RANK_PROVIDER_API_KEY. Demo scans (DEMO_MODE=true) are labelled demo and are not real Google data." },
  ];
  return (<div>
    <PageHead title="Integrations" sub="Connect the services LocalRank AI needs. Nothing here is faked as live." />
    <div className="space-y-3">{items.map((i) => (<div key={i.name} className="card flex flex-wrap justify-between gap-3">
      <div className="max-w-2xl"><h3 className="font-semibold">{i.name} <span className="badge bg-amber-100 text-amber-800 ml-2">{i.status}</span></h3><p className="text-sm text-slate-600 mt-1">{i.detail}</p></div>
      <button className="btn-secondary" onClick={() => setMsg(`${i.name}: configure its keys in Vercel → Settings → Environment Variables, then redeploy. See README.md for the exact steps.`)}>Configure</button>
    </div>))}</div>
    {msg && <p className="text-sm bg-blue-50 p-3 rounded mt-4">{msg}</p>}
    <div className="card mt-4"><h2 className="font-semibold">Env checklist</h2><ul className="text-sm text-slate-600 list-disc pl-5 mt-2 space-y-1">
      <li>DATABASE_URL — Postgres (Supabase / Neon)</li><li>NEXTAUTH_URL, NEXTAUTH_SECRET</li><li>GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GBP_API_ENABLED</li><li>OPENAI_API_KEY (optional)</li><li>STRIPE_SECRET_KEY, STRIPE_PUBLISHABLE_KEY, STRIPE_WEBHOOK_SECRET</li><li>KEYWORD_PROVIDER, RANK_PROVIDER (+ keys), DEMO_MODE</li></ul></div>
  </div>);
}
