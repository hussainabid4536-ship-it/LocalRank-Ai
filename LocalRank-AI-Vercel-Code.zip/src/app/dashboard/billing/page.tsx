"use client";
import { useEffect, useState } from "react";
import { PageHead } from "@/components/ui";
import { PLAN_LIMITS } from "@/lib/permissions";

const PLANS = ["STARTER", "PROFESSIONAL", "AGENCY", "ENTERPRISE"] as const;
export default function BillingPage() {
  const [period, setPeriod] = useState<"monthly" | "yearly">("monthly");
  const [locCount, setLocCount] = useState(0); const [plan, setPlan] = useState("STARTER");
  const [stripe, setStripe] = useState(false);
  useEffect(() => { fetch("/api/locations?perPage=1").then((r) => r.json()).then((d) => setLocCount(d.total || 0)); }, []);
  return (<div>
    <PageHead title="Billing & Subscription" sub="Usage is measured against your plan. Stripe checkout appears only when STRIPE_SECRET_KEY is set.">
      <div className="flex gap-2"><button className={period === "monthly" ? "btn" : "btn-secondary"} onClick={() => setPeriod("monthly")}>Monthly</button><button className={period === "yearly" ? "btn" : "btn-secondary"} onClick={() => setPeriod("yearly")}>Yearly</button></div>
    </PageHead>
    {!stripe && <p className="text-sm text-amber-700 bg-amber-50 p-3 rounded mb-4">Stripe is not connected (no STRIPE_SECRET_KEY). Plan changes below update your subscription record locally; card checkout will show &quot;Connect Stripe&quot; until keys are added in Vercel env vars.</p>}
    <div className="grid md:grid-cols-4 gap-4">
      {PLANS.map((p) => { const l = PLAN_LIMITS[p]; const price = period === "monthly" ? l.monthlyUsd : l.yearlyUsd;
        return (<div key={p} className={`card ${plan === p ? "ring-2 ring-blue-600" : ""}`}>
          <h3 className="font-bold">{l.label}</h3><p className="text-2xl font-bold mt-2">${price}<span className="text-sm font-normal text-slate-500">/{period === "monthly" ? "mo" : "yr"}</span></p>
          <p className="text-sm text-slate-600 mt-2">{l.locations >= 9999 ? "Custom locations" : `${l.locations} location${l.locations > 1 ? "s" : ""}`}</p>
          <button className="btn mt-4 w-full justify-center" onClick={() => { setPlan(p); setStripe(false); }}>{plan === p ? "Current plan" : stripe ? "Checkout with Stripe" : "Switch plan (local)"}</button>
        </div>); })}
    </div>
    <div className="card mt-4"><h2 className="font-semibold">Usage</h2><p className="text-sm text-slate-600 mt-1">Locations used: <b>{locCount}</b> / {PLAN_LIMITS[plan]?.locations ?? 1} on {PLAN_LIMITS[plan]?.label}</p>
    <div className="h-3 bg-slate-200 rounded mt-2"><div className="h-3 bg-blue-600 rounded" style={{ width: `${Math.min(100, (locCount / (PLAN_LIMITS[plan]?.locations ?? 1)) * 100)}%` }} /></div></div>
    <div className="card mt-4"><h2 className="font-semibold">Invoice history</h2><p className="text-sm text-slate-500 mt-1">No invoices yet. Invoices are created by Stripe webhooks once billing is connected (see /api/billing/webhook).</p></div>
  </div>);
}
