"use client";
import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { PageHead } from "@/components/ui";

export default function AnalyticsPage() {
  const [reviews, setReviews] = useState<{ reviewedAt: string; rating: number }[]>([]);
  const [audits, setAudits] = useState<{ score: number; createdAt: string }[]>([]);
  useEffect(() => {
    fetch("/api/reviews?perPage=100").then((r) => r.json()).then((d) => setReviews(d.items || []));
    fetch("/api/audits").then((r) => r.json()).then((d) => setAudits(d.items || []));
  }, []);
  const byMonth: Record<string, { month: string; reviews: number; rating: number; n: number }> = {};
  for (const r of reviews) { const m = new Date(r.reviewedAt).toISOString().slice(0, 7); byMonth[m] = byMonth[m] || { month: m, reviews: 0, rating: 0, n: 0 }; byMonth[m].reviews++; byMonth[m].rating += r.rating; byMonth[m].n++; }
  const chartData = Object.values(byMonth).sort((a, b) => a.month.localeCompare(b.month)).map((d) => ({ month: d.month, reviews: d.reviews, rating: +(d.rating / d.n).toFixed(1) }));
  function exportCsv() {
    const rows = [["month", "reviews", "avg_rating"], ...chartData.map((d) => [d.month, d.reviews, d.rating])];
    const blob = new Blob([rows.map((r) => r.join(",")).join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "localrank-analytics.csv"; a.click();
  }
  return (<div>
    <PageHead title="Analytics & Reports" sub="Charts from your stored data only. Calls, clicks and directions are unavailable until Google is connected.">
      <button className="btn-secondary" onClick={exportCsv}>Export CSV</button>
    </PageHead>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card"><h2 className="font-semibold mb-3">Reviews over time</h2>
        {chartData.length === 0 ? <p className="text-sm text-slate-500">No review data yet.</p> : (
        <div style={{ height: 260 }}><ResponsiveContainer width="100%" height="100%"><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="month" /><YAxis /><Tooltip /><Line type="monotone" dataKey="reviews" stroke="#2563EB" strokeWidth={2} /></LineChart></ResponsiveContainer></div>)}
      </div>
      <div className="card"><h2 className="font-semibold mb-3">Audit score history</h2>
        {audits.length === 0 ? <p className="text-sm text-slate-500">No audits yet — run one from the Audit page.</p> :
        <ul className="text-sm space-y-1">{audits.map((a, i) => (<li key={i}>{new Date(a.createdAt).toLocaleDateString()} — <b>{a.score}/100</b></li>))}</ul>}
        <p className="text-sm text-slate-500 mt-4">Calls: Unavailable — connect Google. Website clicks: Unavailable — connect Google. Direction requests: Unavailable — connect Google.</p>
      </div>
    </div>
  </div>);
}
