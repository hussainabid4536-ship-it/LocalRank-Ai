"use client";
import { useEffect, useState } from "react";
import { PageHead, Empty } from "@/components/ui";

interface Kw { id: string; term: string; intent: string; groupName?: string; service?: string; searchVolume?: number | null; difficulty?: number | null; location?: { name: string } }
interface Loc { id: string; name: string }
export default function KeywordsPage() {
  const [items, setItems] = useState<Kw[]>([]); const [locs, setLocs] = useState<Loc[]>([]); const [locId, setLocId] = useState("");
  const [note, setNote] = useState(""); const [loading, setLoading] = useState(true);
  async function load() { setLoading(true); const r = await fetch("/api/keywords?perPage=50"); const d = await r.json(); setItems(d.items || []); setNote(d.note || ""); setLoading(false); }
  useEffect(() => { load(); fetch("/api/locations?perPage=50").then((r) => r.json()).then((d) => { setLocs(d.items || []); if (d.items?.[0]) setLocId(d.items[0].id); }); }, []);
  async function discover() { if (!locId) return; const r = await fetch("/api/keywords", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ discoverFor: locId }) }); if (r.ok) load(); }
  return (<div>
    <PageHead title="Keyword Research" sub="Rule-based discovery from category + city + services.">
      <select value={locId} onChange={(e) => setLocId(e.target.value)} className="!w-auto">{locs.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
      <button className="btn" onClick={discover} disabled={!locId}>Discover keywords</button>
    </PageHead>
    <p className="text-sm text-amber-700 bg-amber-50 p-2 rounded mb-3">{note || "Search volume and difficulty show as — until a keyword provider is connected. Values are never estimated."}</p>
    {loading ? <p className="text-slate-500">Loading…</p> : items.length === 0 ? <Empty title="No keywords yet" body="Pick a location and run Discover, or add keywords manually via the API." /> :
    <div className="card overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-slate-500"><th className="py-2">Keyword</th><th>Intent</th><th>Group</th><th>Service</th><th>Volume</th><th>Difficulty</th></tr></thead>
    <tbody>{items.map((k) => (<tr key={k.id} className="border-t"><td className="py-2 font-medium">{k.term}</td><td>{k.intent}</td><td>{k.groupName || "—"}</td><td>{k.service || "—"}</td><td>{k.searchVolume ?? "—"}</td><td>{k.difficulty ?? "—"}</td></tr>))}</tbody></table></div>}
  </div>);
}
