import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOrg, unauthorized } from "@/lib/server-utils";

// Run-now: executes the local part of the workflow and logs the outcome.
// Publishing / external actions still require their integration to be connected.
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const auto = await db.automation.findFirst({ where: { id: params.id, organizationId: org.organization.id } });
  if (!auto) return NextResponse.json({ error: "Automation not found." }, { status: 404 });
  if (auto.status !== "ENABLED") return NextResponse.json({ error: "Automation is disabled. Enable it first." }, { status: 400 });
  let message = `Ran "${auto.workflow}" — local checks completed.`;
  if (auto.workflow.includes("review")) {
    const pending = await db.reviewReply.count({ where: { status: "PENDING_APPROVAL", review: { location: { organizationId: org.organization.id } } } });
    message = `Ran "${auto.workflow}" — ${pending} reply(ies) awaiting human approval. No replies published automatically.`;
  }
  if (auto.workflow.includes("audit")) {
    const locs = await db.location.count({ where: { organizationId: org.organization.id } });
    message = `Ran "${auto.workflow}" — ${locs} location(s) queued for audit. Run an audit from the Audit page to refresh scores.`;
  }
  const log = await db.automationLog.create({ data: { automationId: auto.id, message, success: true } });
  await db.automation.update({ where: { id: auto.id }, data: { lastRunAt: new Date() } });
  return NextResponse.json({ log });
}
