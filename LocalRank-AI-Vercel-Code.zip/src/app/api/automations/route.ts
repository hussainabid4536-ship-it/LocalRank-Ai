import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOrg, unauthorized } from "@/lib/server-utils";

export async function GET() {
  const org = await requireOrg(); if (!org) return unauthorized();
  const items = await db.automation.findMany({ where: { organizationId: org.organization.id }, orderBy: { createdAt: "asc" }, include: { logs: { orderBy: { createdAt: "desc" }, take: 5 } } });
  return NextResponse.json({ items });
}
export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body?.id || typeof body?.status !== "string") return NextResponse.json({ error: "id and status required." }, { status: 400 });
  const auto = await db.automation.findFirst({ where: { id: body.id, organizationId: org.organization.id } });
  if (!auto) return NextResponse.json({ error: "Automation not found." }, { status: 404 });
  const updated = await db.automation.update({ where: { id: body.id }, data: { status: body.status === "ENABLED" ? "ENABLED" : "DISABLED" } });
  return NextResponse.json(updated);
}
