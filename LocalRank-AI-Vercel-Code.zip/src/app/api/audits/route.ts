import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOrg, unauthorized } from "@/lib/server-utils";
import { runAudit } from "@/lib/audit-engine";

export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const body = await req.json().catch(() => null);
  const loc = await db.location.findFirst({ where: { id: body?.locationId, organizationId: org.organization.id }, include: { reviews: true, _count: { select: { reviews: true } } } });
  if (!loc) return NextResponse.json({ error: "Location not found." }, { status: 404 });
  const keywords = await db.keyword.findMany({ where: { locationId: loc.id }, select: { term: true } });
  const recent = loc.reviews.filter((r: { reviewedAt: Date }) => r.reviewedAt > new Date(Date.now() - 30 * 864e5)).length;
  const avg = loc.reviews.length ? loc.reviews.reduce((s: number, r: { rating: number }) => s + r.rating, 0) / loc.reviews.length : 0;
  const result = runAudit({ name: loc.name, category: loc.category, description: loc.description, phone: loc.phone, website: loc.website, hours: loc.hours, photoCount: loc.photoCount, services: [], keywords: keywords.map((k: { term: string }) => k.term), avgRating: avg, reviewCount: loc.reviews.length, recentReviews: recent, city: loc.city });
  const audit = await db.seoAudit.create({ data: { locationId: loc.id, score: result.score, issuesJson: JSON.stringify(result.issues), recommendationsJson: JSON.stringify(result.recommendations), checksJson: JSON.stringify(result.checks) } });
  for (const rec of result.recommendations.slice(0, 10)) {
    await db.seoRecommendation.create({ data: { locationId: loc.id, title: rec.slice(0, 120), detail: rec, priority: "MEDIUM" } });
  }
  return NextResponse.json({ ...audit, checks: result.checks, issues: result.issues, recommendations: result.recommendations });
}
export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const locationId = req.nextUrl.searchParams.get("locationId");
  const locIds = (await db.location.findMany({ where: { organizationId: org.organization.id }, select: { id: true } })).map((l: { id: string }) => l.id);
  const items = await db.seoAudit.findMany({ where: locationId ? { locationId } : { locationId: { in: locIds } }, orderBy: { createdAt: "desc" }, take: 20, include: { location: true } });
  return NextResponse.json({ items });
}
