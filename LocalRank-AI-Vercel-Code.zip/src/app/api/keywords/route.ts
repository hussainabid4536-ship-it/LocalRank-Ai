import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, paginate } from "@/lib/server-utils";

// Keyword discovery is rule-based from category + city + services.
// Search volume / difficulty are NEVER fabricated: they stay null and the UI
// shows "—" with "Connect a keyword provider" until a provider is configured.
const INTENT: Record<string, string> = { "near me": "Transactional", best: "Transactional", price: "Transactional", cost: "Transactional", how: "Informational", what: "Informational", top: "Commercial" };

export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const { skip, take, page, perPage } = paginate(req.nextUrl.searchParams);
  const where = { organizationId: org.organization.id };
  const [items, total] = await Promise.all([db.keyword.findMany({ where, skip, take, orderBy: { createdAt: "desc" }, include: { location: true } }), db.keyword.count({ where })]);
  return NextResponse.json({ items, total, page, perPage, provider: process.env.KEYWORD_PROVIDER || null, note: process.env.KEYWORD_PROVIDER ? "Volume/difficulty from configured provider." : "Volume/difficulty unavailable — connect a keyword provider. Values are not estimated." });
}

export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const body = await req.json().catch(() => null);
  // Discovery mode: generate suggestions for a location
  if (body?.discoverFor) {
    const loc = await db.location.findFirst({ where: { id: body.discoverFor, organizationId: org.organization.id } });
    if (!loc) return NextResponse.json({ error: "Location not found." }, { status: 404 });
    const cat = loc.category.toLowerCase(); const city = (loc.city || "Islamabad").toLowerCase();
    const terms = [`${cat} in ${city}`, `best ${cat} in ${city}`, `${cat} near me`, `${cat} ${city} price`, `top ${cat} ${city}`];
    const created = [];
    for (const term of terms) {
      const intent = Object.entries(INTENT).find(([k]) => term.includes(k))?.[1] || "Informational";
      created.push(await db.keyword.upsert({ where: { id: `${org.organization.id}-${term}`.slice(0, 24) }, update: {}, create: { organizationId: org.organization.id, locationId: loc.id, term, intent, groupName: "Core", service: loc.category, source: "rule-based" } }).catch(() =>
        db.keyword.create({ data: { organizationId: org.organization.id, locationId: loc.id, term, intent, groupName: "Core", service: loc.category, source: "rule-based" } })));
    }
    return NextResponse.json({ items: created }, { status: 201 });
  }
  const schema = z.object({ term: z.string().min(2), locationId: z.string().optional(), intent: z.string().optional(), groupName: z.string().optional(), service: z.string().optional() });
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const kw = await db.keyword.create({ data: { ...parsed.data, organizationId: org.organization.id, source: "manual" } });
  return NextResponse.json(kw, { status: 201 });
}
