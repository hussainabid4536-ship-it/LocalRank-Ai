import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, forbidden, paginate } from "@/lib/server-utils";
import { canDo } from "@/lib/permissions";
import { classifySentiment, draftReply } from "@/lib/sentiment";

export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const sp = req.nextUrl.searchParams;
  const { skip, take, page, perPage } = paginate(sp);
  const locIds = (await db.location.findMany({ where: { organizationId: org.organization.id }, select: { id: true } })).map((l: { id: string }) => l.id);
  const where: Record<string, unknown> = { locationId: { in: locIds } };
  if (sp.get("locationId")) where.locationId = sp.get("locationId");
  if (sp.get("rating")) where.rating = Number(sp.get("rating"));
  if (sp.get("from")) where.reviewedAt = { gte: new Date(sp.get("from")!) };
  const [items, total] = await Promise.all([
    db.review.findMany({ where, skip, take, orderBy: { reviewedAt: "desc" }, include: { location: true, replies: { orderBy: { createdAt: "desc" } } } }),
    db.review.count({ where }),
  ]);
  return NextResponse.json({ items, total, page, perPage });
}

export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body?.locationId || !body?.authorName || typeof body?.rating !== "number") return NextResponse.json({ error: "locationId, authorName and rating are required." }, { status: 400 });
  const loc = await db.location.findFirst({ where: { id: body.locationId, organizationId: org.organization.id } });
  if (!loc) return NextResponse.json({ error: "Location not found in your organisation." }, { status: 404 });
  const sentiment = classifySentiment(body.text, body.rating);
  const review = await db.review.create({ data: { locationId: loc.id, authorName: body.authorName, rating: body.rating, text: body.text || null, sentiment, reviewedAt: body.reviewedAt ? new Date(body.reviewedAt) : new Date() } });
  if (body.rating <= 2) {
    await db.notification.create({ data: { userId: org.user.id, title: "Negative review needs approval", body: `${body.authorName} left a ${body.rating}-star review at ${loc.name}. A reply requires human approval.` } });
  }
  return NextResponse.json(review, { status: 201 });
}
