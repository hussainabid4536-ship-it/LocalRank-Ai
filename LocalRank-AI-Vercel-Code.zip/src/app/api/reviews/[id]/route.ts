import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, forbidden } from "@/lib/server-utils";
import { canDo } from "@/lib/permissions";
import { draftReply } from "@/lib/sentiment";

// POST /api/reviews/[id] — generate an AI reply draft (rule-based fallback;
// OpenAI used only when OPENAI_API_KEY is set — see note in handler).
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const org = await requireOrg(); if (!org) return unauthorized();
  if (!canDo(org.role, "reviews", "reply")) return forbidden();
  const body = await req.json().catch(() => ({}));
  const tone = typeof body?.tone === "string" ? body.tone : "Professional";
  const review = await db.review.findUnique({ where: { id: params.id }, include: { location: true } });
  if (!review) return NextResponse.json({ error: "Review not found." }, { status: 404 });
  const loc = await db.location.findFirst({ where: { id: review.locationId, organizationId: org.organization.id } });
  if (!loc) return forbidden();
  let text = draftReply({ businessName: loc.name, author: review.authorName, rating: review.rating, text: review.text, tone });
  let source = "rule-based generator";
  if (process.env.OPENAI_API_KEY) {
    try {
      const { default: OpenAI } = await import("openai");
      const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      const res = await client.chat.completions.create({ model: "gpt-4o-mini", messages: [{ role: "user", content: `Draft a ${tone} reply to this ${review.rating}-star review for ${loc.name} from ${review.authorName}: "${review.text || ""}". Keep it under 500 characters, no personal data.` }], max_tokens: 200 });
      if (res.choices[0]?.message?.content) { text = res.choices[0].message.content.trim(); source = "openai"; }
    } catch { /* fall through to rule-based draft */ }
  }
  const reply = await db.reviewReply.create({ data: { reviewId: review.id, body: text, tone, status: review.rating <= 2 ? "PENDING_APPROVAL" : "DRAFT", createdBy: org.user.id } });
  return NextResponse.json({ ...reply, source, note: review.rating <= 2 ? "Negative review — this draft requires human approval before publishing." : undefined });
}
