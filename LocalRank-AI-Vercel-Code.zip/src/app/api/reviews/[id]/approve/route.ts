import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, forbidden } from "@/lib/server-utils";
import { canDo } from "@/lib/permissions";

// Approve (and mark published) a reply draft. Negative reviews REQUIRE this
// human approval step — replies can never be published without it.
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const org = await requireOrg(); if (!org) return unauthorized();
  if (!canDo(org.role, "reviews", "approve")) return forbidden("Only an approver role can approve replies.");
  const reply = await db.reviewReply.findUnique({ where: { id: params.id }, include: { review: true } });
  if (!reply) return NextResponse.json({ error: "Reply not found." }, { status: 404 });
  const loc = await db.location.findFirst({ where: { id: reply.review.locationId, organizationId: org.organization.id } });
  if (!loc) return forbidden();
  const updated = await db.reviewReply.update({ where: { id: params.id }, data: { status: "PUBLISHED" } });
  await db.auditLog.create({ data: { userId: org.user.id, organizationId: org.organization.id, action: "review.reply.publish", detail: `Reply published for ${reply.review.authorName} (${reply.review.rating}★)` } });
  return NextResponse.json({ ...updated, note: "Marked published in LocalRank. Actual GBP publishing happens via the Google integration once connected." });
}
