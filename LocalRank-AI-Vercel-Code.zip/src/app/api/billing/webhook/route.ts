import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Stripe webhook — stub until STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET are set.
// When configured, verify the signature with the Stripe SDK and update the
// Subscription / Invoice records. Never trust an unverified webhook payload.
export async function POST(req: NextRequest) {
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ received: false, note: "Stripe webhook is pending integration — STRIPE_WEBHOOK_SECRET is not set." }, { status: 200 });
  }
  const body = await req.text();
  try {
    const { default: Stripe } = await import("stripe");
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
    const sig = req.headers.get("stripe-signature") || "";
    const event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    if (event.type === "invoice.payment_succeeded") {
      const invoice = event.data.object as { customer?: string; amount_paid?: number; id?: string };
      await db.auditLog.create({ data: { action: "stripe.invoice.paid", detail: `Stripe invoice ${invoice.id} paid (${invoice.amount_paid})` } });
    }
    return NextResponse.json({ received: true, type: event.type });
  } catch (err) {
    return NextResponse.json({ error: "Webhook signature verification failed." }, { status: 400 });
  }
}
