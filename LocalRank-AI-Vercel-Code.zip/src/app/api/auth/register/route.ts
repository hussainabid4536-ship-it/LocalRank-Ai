import { NextRequest, NextResponse } from "next/server";
import { hash } from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";

const schema = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(8), orgName: z.string().min(2) });

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const { name, email, password, orgName } = parsed.data;
  const existing = await db.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) return NextResponse.json({ error: "An account with this email already exists." }, { status: 400 });
  const slug = orgName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + Date.now().toString(36);
  const user = await db.user.create({ data: { name, email: email.toLowerCase(), passwordHash: await hash(password, 10) } });
  const org = await db.organization.create({ data: { name: orgName, slug, plan: "STARTER" } });
  await db.membership.create({ data: { userId: user.id, organizationId: org.id, role: "AGENCY_OWNER" } });
  await db.subscription.create({ data: { organizationId: org.id, plan: "STARTER", billingPeriod: "monthly", status: "TRIALING" } });
  const defaults = ["New review notification","AI review reply draft generation","Negative review alert","Weekly SEO audit","Monthly performance report","Google profile change notification","OAuth connection expiry alert","Scheduled Google Posts","Keyword ranking monitoring","Pending approval reminders"];
  await db.automation.createMany({ data: defaults.map((n) => ({ organizationId: org.id, name: n, workflow: n, status: "ENABLED" as const, schedule: "daily" })) });
  return NextResponse.json({ ok: true });
}
