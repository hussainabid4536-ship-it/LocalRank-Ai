import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, forbidden, paginate } from "@/lib/server-utils";
import { PLAN_LIMITS, canDo } from "@/lib/permissions";

const schema = z.object({ name: z.string().min(2), category: z.string().optional(), description: z.string().max(750).optional(), address: z.string().optional(), city: z.string().optional(), phone: z.string().optional(), website: z.string().optional(), hours: z.string().optional(), photoCount: z.number().int().min(0).optional(), clientId: z.string().optional() });

export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const { skip, take, page, perPage } = paginate(req.nextUrl.searchParams);
  const where = { organizationId: org.organization.id };
  const [items, total] = await Promise.all([db.location.findMany({ where, skip, take, orderBy: { createdAt: "desc" }, include: { _count: { select: { reviews: true, posts: true } } } }), db.location.count({ where })]);
  return NextResponse.json({ items, total, page, perPage });
}

export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  if (!canDo(org.role, "locations", "manage")) return forbidden();
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const limit = PLAN_LIMITS[org.organization.plan]?.locations ?? 1;
  const count = await db.location.count({ where: { organizationId: org.organization.id } });
  if (count >= limit) return NextResponse.json({ error: `Plan limit reached: ${org.organization.plan} allows ${limit} location(s). Upgrade in Billing.` }, { status: 403 });
  const loc = await db.location.create({ data: { ...parsed.data, organizationId: org.organization.id } });
  await db.auditLog.create({ data: { userId: org.user.id, organizationId: org.organization.id, action: "location.create", detail: loc.name } });
  return NextResponse.json(loc, { status: 201 });
}
