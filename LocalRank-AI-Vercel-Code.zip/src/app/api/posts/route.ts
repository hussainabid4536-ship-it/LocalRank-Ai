import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, paginate } from "@/lib/server-utils";

const schema = z.object({ locationId: z.string(), type: z.enum(["WHATS_NEW","OFFER","EVENT"]), title: z.string().min(2), body: z.string().min(2).max(1500), ctaText: z.string().optional(), ctaUrl: z.string().optional(), imageUrl: z.string().optional(), scheduledAt: z.string().optional(), status: z.enum(["DRAFT","SCHEDULED"]).optional() });

export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const { skip, take, page, perPage } = paginate(req.nextUrl.searchParams);
  const locIds = (await db.location.findMany({ where: { organizationId: org.organization.id }, select: { id: true } })).map((l: { id: string }) => l.id);
  const where = { locationId: { in: locIds } };
  const [items, total] = await Promise.all([db.post.findMany({ where, skip, take, orderBy: { createdAt: "desc" }, include: { location: true } }), db.post.count({ where })]);
  return NextResponse.json({ items, total, page, perPage });
}
export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const loc = await db.location.findFirst({ where: { id: parsed.data.locationId, organizationId: org.organization.id } });
  if (!loc) return NextResponse.json({ error: "Location not found." }, { status: 404 });
  const post = await db.post.create({ data: { ...parsed.data, scheduledAt: parsed.data.scheduledAt ? new Date(parsed.data.scheduledAt) : null, status: parsed.data.status || "DRAFT" } });
  return NextResponse.json({ ...post, note: "Saved as draft/scheduled in LocalRank. Publishing to Google requires the GBP integration (Settings → Integrations)." }, { status: 201 });
}
