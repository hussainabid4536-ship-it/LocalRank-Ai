import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOrg, unauthorized, paginate } from "@/lib/server-utils";

const schema = z.object({ name: z.string().min(2), locationId: z.string().optional(), rating: z.number().min(0).max(5).optional(), reviewCount: z.number().int().min(0).optional(), category: z.string().optional(), completeness: z.number().int().min(0).max(100).optional(), notes: z.string().optional() });

export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const { skip, take, page, perPage } = paginate(req.nextUrl.searchParams);
  const where = { organizationId: org.organization.id };
  const [items, total] = await Promise.all([db.competitor.findMany({ where, skip, take, orderBy: { createdAt: "desc" }, include: { location: true } }), db.competitor.count({ where })]);
  return NextResponse.json({ items, total, page, perPage });
}
export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const c = await db.competitor.create({ data: { ...parsed.data, organizationId: org.organization.id } });
  return NextResponse.json(c, { status: 201 });
}
