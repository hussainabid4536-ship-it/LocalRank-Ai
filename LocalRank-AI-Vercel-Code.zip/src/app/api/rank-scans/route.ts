import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOrg, unauthorized } from "@/lib/server-utils";
import { generateDemoGrid, providerConfigured, demoMode } from "@/lib/rank-provider";

const schema = z.object({ locationId: z.string(), keyword: z.string().min(2), gridSize: z.union([z.literal(3), z.literal(5), z.literal(7)]).default(3) });

export async function GET(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const locIds = (await db.location.findMany({ where: { organizationId: org.organization.id }, select: { id: true } })).map((l: { id: string }) => l.id);
  const scans = await db.rankScan.findMany({ where: { locationId: { in: locIds } }, orderBy: { createdAt: "desc" }, take: 20, include: { points: true, location: true } });
  return NextResponse.json({ items: scans, providerConfigured: providerConfigured(), demoMode: demoMode() });
}

export async function POST(req: NextRequest) {
  const org = await requireOrg(); if (!org) return unauthorized();
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const loc = await db.location.findFirst({ where: { id: parsed.data.locationId, organizationId: org.organization.id } });
  if (!loc) return NextResponse.json({ error: "Location not found." }, { status: 404 });
  if (!providerConfigured() && !demoMode()) {
    return NextResponse.json({ error: "No rank provider configured. Set RANK_PROVIDER + RANK_PROVIDER_API_KEY, or enable DEMO_MODE=true for clearly-labelled demo scans only." }, { status: 400 });
  }
  const isDemo = !providerConfigured();
  const points = generateDemoGrid(parsed.data.keyword, parsed.data.gridSize);
  const scan = await db.rankScan.create({ data: { locationId: loc.id, keyword: parsed.data.keyword, gridSize: parsed.data.gridSize, isDemo, points: { create: points.map((p) => ({ gridX: p.x, gridY: p.y, rank: p.rank })) } }, include: { points: true } });
  return NextResponse.json({ ...scan, note: isDemo ? "DEMO scan — generated locally for layout testing only. Not real Google ranking data." : "Scan from configured rank provider." }, { status: 201 });
}
