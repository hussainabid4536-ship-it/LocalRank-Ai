"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const [form, setForm] = useState({ name: "", email: "", password: "", orgName: "" });
  const [error, setError] = useState(""); const [loading, setLoading] = useState(false);
  const router = useRouter();
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });
  async function submit(e: React.FormEvent) { e.preventDefault(); setLoading(true); setError("");
    const res = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { setError(data.error || "Could not create account."); setLoading(false); return; }
    const login = await signIn("credentials", { email: form.email, password: form.password, redirect: false });
    setLoading(false);
    if (login?.error) router.push("/login"); else router.push("/dashboard");
  }
  return (<main className="min-h-screen flex items-center justify-center px-4"><form onSubmit={submit} className="card w-full max-w-md space-y-4">
    <h1 className="text-2xl font-bold text-navy">Create your workspace</h1>
    <p className="text-sm text-slate-600">Your organisation is created on first login — all data is isolated per organisation.</p>
    {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</p>}
    <div><label className="label">Your name</label><input required value={form.name} onChange={set("name")} /></div>
    <div><label className="label">Organisation name</label><input required value={form.orgName} onChange={set("orgName")} placeholder="AF Digital Marketing" /></div>
    <div><label className="label">Email</label><input type="email" required value={form.email} onChange={set("email")} /></div>
    <div><label className="label">Password (min 8 characters)</label><input type="password" required minLength={8} value={form.password} onChange={set("password")} /></div>
    <button className="btn w-full justify-center" disabled={loading}>{loading ? "Creating…" : "Create account & workspace"}</button>
    <p className="text-sm text-slate-600">Already have an account? <Link className="text-blue-600" href="/login">Sign in</Link></p>
  </form></main>);
}
