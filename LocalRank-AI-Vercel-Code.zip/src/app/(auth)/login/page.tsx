"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [error, setError] = useState(""); const [loading, setLoading] = useState(false);
  const router = useRouter();
  async function submit(e: React.FormEvent) { e.preventDefault(); setLoading(true); setError("");
    const res = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);
    if (res?.error) setError("Invalid email or password."); else router.push("/dashboard");
  }
  return (<main className="min-h-screen flex items-center justify-center px-4"><form onSubmit={submit} className="card w-full max-w-md space-y-4">
    <h1 className="text-2xl font-bold text-navy">Sign in to LocalRank AI</h1>
    {error && <p className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</p>}
    <div><label className="label">Email</label><input type="email" required value={email} onChange={(e)=>setEmail(e.target.value)} /></div>
    <div><label className="label">Password</label><input type="password" required value={password} onChange={(e)=>setPassword(e.target.value)} /></div>
    <button className="btn w-full justify-center" disabled={loading}>{loading ? "Signing in…" : "Sign in"}</button>
    <p className="text-sm text-slate-600">No account? <Link className="text-blue-600" href="/register">Create one</Link></p>
  </form></main>);
}
