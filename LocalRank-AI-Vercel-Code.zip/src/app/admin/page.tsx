"use client";
import { useEffect, useState } from "react";
import { PageHead } from "@/components/ui";

// Super Admin surface. The underlying admin APIs are organisation-scoped
// reads in this build; full user/org suspension actions run from the database
// or the admin API added under /api/admin. Access is restricted by role:
// only users with isSuperAdmin (or SUPER_ADMIN membership) should reach here.
export default function AdminPage() {
  const [stats, setStats] = useState({ locations: 0, reviews: 0, posts: 0 });
  useEffect(() => {
    (async () => {
      const [l, r, p] = await Promise.all([fetch("/api/locations?perPage=1").then((x) => x.json()), fetch("/api/reviews?perPage=1").then((x) => x.json()), fetch("/api/posts?perPage=1").then((x) => x.json())]);
      setStats({ locations: l.total || 0, reviews: r.total || 0, posts: p.total || 0 });
    })();
  }, []);
  return (<div>
    <PageHead title="Super Admin" sub="Platform administration. Restricted to Super Admins — enforce isSuperAdmin in your deployment (see README)." />
    <div className="grid md:grid-cols-3 gap-4">
      <div className="card"><p className="text-xs text-slate-500">Locations (this org view)</p><p className="text-2xl font-bold">{stats.locations}</p></div>
      <div className="card"><p className="text-xs text-slate-500">Reviews (this org view)</p><p className="text-2xl font-bold">{stats.reviews}</p></div>
      <div className="card"><p className="text-xs text-slate-500">Posts (this org view)</p><p className="text-2xl font-bold">{stats.posts}</p></div>
    </div>
    <div className="card mt-4"><h2 className="font-semibold mb-2">Admin capabilities (checklist)</h2>
      <ul className="text-sm text-slate-700 list-disc pl-5 space-y-1">
        <li>Manage users & organisations — Prisma Studio (`npm run db:studio`) or the /api/admin endpoints.</li>
        <li>Manage plans & pricing — edit PLAN_LIMITS in src/lib/permissions.ts and the Billing page.</li>
        <li>Monitor connected Google accounts — GoogleConnection table (status, token expiry, last sync).</li>
        <li>Monitor automation jobs — Automation + AutomationLog tables (see Automations page logs).</li>
        <li>View errors — AuditLog table; add Sentry (SENTRY_DSN) for production error tracking.</li>
        <li>Suspend / reactivate accounts — set Subscription.status to CANCELED / ACTIVE.</li>
      </ul>
      <p className="text-sm text-amber-700 bg-amber-50 p-2 rounded mt-3">This page currently shows organisation-scoped counts. Before opening sign-ups publicly, gate /admin by isSuperAdmin server-side (middleware + a server check in this page).</p>
    </div>
  </div>);
}
