import "./globals.css";
import type { Metadata } from "next";
import { Inter } from "next/font/google";
const inter = Inter({ subsets: ["latin"] });
export const metadata: Metadata = { title: "LocalRank AI — Local SEO & Google Business Profile SaaS", description: "Manage Google Business Profiles, local SEO audits, reviews, posts and rankings from one dashboard." };
import Providers from "@/components/providers";
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className={inter.className}><Providers>{children}</Providers></body></html>);
}
