# LocalRank AI — Deployable SaaS Codebase

AI-powered Google Business Profile management & local SEO SaaS for agencies
and local business owners. Next.js 14, TypeScript, Tailwind, Prisma +
PostgreSQL, NextAuth, Stripe, OpenAI (optional).

## What is built

- **Auth & multi-tenancy** — email/password + Google OAuth, organisation
  created on first sign-up, every query scoped by `organisationId`.
- **Dashboard** — KPIs from the database, 7/30/90-day filter, pending
  approvals, AI recommendations. Metrics with no connected data show
  "Unavailable — connect Google", never fake numbers.
- **Locations** — CRUD + full GBP profile editor, plan limits enforced.
- **AI SEO Audit** — deterministic 0–100 scorer (`src/lib/audit-engine.ts`,
  13 checks), issues, recommendations, checklist, before/after comparison,
  print/PDF via the browser.
- **Content Studio** — description / service / post / meta generators
  (rule-based from your business details; OpenAI used only when
  `OPENAI_API_KEY` is set), editable output, character-limit validation.
- **Reviews** — inbox with filters, rule-based sentiment, AI reply drafts
  in 6 tones, edit before publish. **Negative reviews (1–2★) REQUIRE
  human approval** before a reply is marked published.
- **Google Posts** — composer with live preview, What's New / Offer /
  Event, CTA, scheduling, drafts. Actual GBP publishing needs the Google
  integration (see below).
- **Keywords** — rule-based discovery, intent, grouping, service mapping.
  Volume/difficulty show "—" until a keyword provider is connected.
- **Rank Tracker** — 3×3 / 5×5 / 7×7 grid heatmaps, scan history.
  Rank data only from `src/lib/rank-provider.ts`; demo scans exist only
  in `DEMO_MODE=true` and are labelled demo.
- **Competitors** — CRUD + rule-based gap insights.
- **Analytics** — Recharts, CSV export.
- **Automations** — all 10 workflows, enable/disable, run-now, execution logs.
- **Clients & Team** — roles (Super Admin → Business Staff) in
  `src/lib/permissions.ts`, server-side checks in API routes.
- **Billing** — 4 plans, monthly/yearly, usage meter, invoice history.
  Stripe checkout only when keys are set; otherwise "Connect Stripe".
- **Super Admin** — `/admin` section (gate by `isSuperAdmin` before public launch).
- **Integrations** — `/dashboard/settings/integrations` with a pending-integration
  checklist for Google, OpenAI, Stripe, keyword and rank providers.

## Deploy to Vercel (step by step)

### 1. Create a Postgres database (free tier)
- **Supabase**: supabase.com → New project → Settings → Database → copy the
  connection string (use the pooled / `?sslmode=require` form).
- Or **Neon**: neon.tech → New project → copy the connection string.
- Keep the password safe — it goes in `DATABASE_URL` only.

### 2. Push the code
```bash
git init && git add . && git commit -m "LocalRank AI"
# create a repo on GitHub and push, or use `vercel` CLI: npx vercel
```

### 3. Import in Vercel
- vercel.com → Add New → Project → import your repo.
- Framework: Next.js (auto-detected). Build command: `npm run build`.

### 4. Set environment variables (Vercel → Settings → Environment Variables)
Copy every key from `.env.example`. Minimum to launch:
```
DATABASE_URL=postgresql://...
NEXTAUTH_URL=https://your-domain.vercel.app
NEXTAUTH_SECRET=<long random string — generate with: openssl rand -base64 32>
```
Optional (features stay "pending integration" until set):
```
GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / GBP_API_ENABLED=false
OPENAI_API_KEY=
STRIPE_SECRET_KEY / STRIPE_PUBLISHABLE_KEY / STRIPE_WEBHOOK_SECRET=
KEYWORD_PROVIDER / KEYWORD_PROVIDER_API_KEY=
RANK_PROVIDER / RANK_PROVIDER_API_KEY=
DEMO_MODE=false
```

### 5. Run migrations
```bash
npx prisma db push        # creates tables (no migration files needed to start)
# or: npx prisma migrate deploy   (once you generate migrations)
```

### 6. Seed demo data (optional, once)
```bash
npm run db:seed
# Demo login: demo@localrank.ai / demo1234 — change/delete this account
# before going live. Seed never runs automatically on deploy.
```

### 7. Connect Google (GBP API)
1. Google Cloud Console → create project → enable **Google Business
   Profile API** (requires Google approval for production use).
2. Create OAuth 2.0 credentials (Web app) → authorised redirect URI:
   `https://your-domain.vercel.app/api/auth/callback/google`
3. Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GBP_API_ENABLED=true`.
4. In the app: Settings → Integrations → Google → Connect, then import
   only the locations that account is authorised for.

### 8. Connect Stripe (billing)
1. stripe.com → Developers → API keys → copy secret + publishable keys.
2. Add a webhook endpoint: `https://your-domain.vercel.app/api/billing/webhook`
   (events: `invoice.payment_succeeded`, `customer.subscription.*`).
3. Set the three Stripe env vars and redeploy.

### 9. Connect OpenAI (optional)
Set `OPENAI_API_KEY`. Without it, AI features use the built-in
deterministic generator — clearly labelled, never presented as a live call.

## Local development
```bash
npm install
cp .env.example .env.local   # fill in DATABASE_URL + NEXTAUTH_SECRET
npx prisma db push
npm run dev                  # http://localhost:3000
npm run db:seed              # optional demo data
```

## Pre-launch checklist
- [ ] `NEXTAUTH_SECRET` is a long random value (not the dev default)
- [ ] Demo seed account deleted or password changed
- [ ] `/admin` gated by `isSuperAdmin` (see `src/app/admin/page.tsx` note)
- [ ] Google Cloud project + GBP API approval (if using live sync)
- [ ] Stripe keys + webhook configured (if charging customers)
- [ ] `DEMO_MODE=false` in production
- [ ] Custom domain + `NEXTAUTH_URL` updated to match it
- [ ] Sentry / error monitoring added for production (optional)

## Honesty rules built in
- No scraped Google Maps data, ever (`src/lib/google.ts` throws a clear
  pending-integration error until configured).
- No fabricated search volumes, difficulty scores, ranks or performance
  metrics. Unavailable data is labelled unavailable.
- No fake reviews, no auto-published replies, no real credentials in code.
